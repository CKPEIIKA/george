// SPDX-License-Identifier: MIT
// Extension to the existing George form. Mathematical options stay in George.
import {requestPersistentStorage,listCachedRuns,deleteCachedRun} from './storage.js';
import {browserCapabilities} from './capabilities.js';
import {requestIsolation} from './isolation.js';
const KEY='fomkyr-options-v3';
const defaults={workers:0,execution:'auto',bits:'auto',spill:true,hilbert:true,resume:'auto',ioMode:'auto',monomialPruning:true,heapReduction:true,cachePercent:12,heapThreshold:16,batchPairs:null,hashBits:18,scratchMiB:null,hilbertMiB:256};
let state={...defaults};
try{const saved=JSON.parse(globalThis.localStorage?.getItem(KEY)||'{}');for(const key of Object.keys(defaults))if(Object.hasOwn(saved,key))state[key]=saved[key];}catch{}
function persist(){try{localStorage.setItem(KEY,JSON.stringify(state));}catch{}}
export function readFomkyrOptions(){
  const out={...state};delete out.scratchMiB;delete out.hilbertMiB;
  if(out.batchPairs===null)delete out.batchPairs;
  if(state.scratchMiB!==null)out.scratchBytes=Number(state.scratchMiB)*1048576;
  out.hilbertBudgetBytes=Number(state.hilbertMiB)*1048576;
  if(typeof document!=='undefined'){
    const workers=document.getElementById('nativeWorkers'),prune=document.getElementById('monomialPruning');
    if(workers)out.workers=Number(workers.value);
    if(prune)out.monomialPruning=prune.checked;
  }
  return out;
}
export function installFomkyrControls(){
  const select=document.querySelector('#backend');if(!select||document.getElementById('fomkyr-options'))return;
  const box=document.createElement('fieldset');box.id='fomkyr-options';
  const legend=document.createElement('legend');legend.textContent='fomkyr: runtime, memory and exact Hilbert coefficients';box.append(legend);
  function label(text,parent=box){const el=document.createElement('label');el.style.display='block';el.style.margin='0.35em 0';el.append(document.createTextNode(text+' '));parent.append(el);return el;}
  function choice(key,text,values,parent=box){const row=label(text,parent),input=document.createElement('select');input.id='fomkyr-'+key;for(const [value,name] of values){const o=document.createElement('option');o.value=value;o.textContent=name;input.append(o);}input.value=state[key];input.onchange=()=>{state[key]=input.value;persist();};row.append(input);return input;}
  function number(key,text,min,max,parent=box){const row=label(text,parent),input=document.createElement('input');input.type='number';input.id='fomkyr-'+key;input.min=min;if(max!=null)input.max=max;input.step='1';input.value=state[key]??'';input.placeholder='automatic';input.style.width='7em';input.onchange=()=>{const v=input.value===''?null:Number(input.value);if(v!==null&&(!Number.isInteger(v)||v<min||max!=null&&v>max)){input.setCustomValidity(`Enter an integer from ${min} to ${max??'the available budget'}, or leave automatic.`);return;}input.setCustomValidity('');state[key]=v;persist();};row.append(input);return input;}
  function check(key,text,parent=box){const row=label('',parent),input=document.createElement('input');input.id='fomkyr-'+key;input.type='checkbox';input.checked=!!state[key];input.onchange=()=>{state[key]=key==='resume'?(input.checked?'auto':false):input.checked;persist();};row.append(input,document.createTextNode(' '+text));return input;}
  choice('execution','Execution',[['auto','Automatic: shared multicore when available'],['single','Single worker: no shared-memory requirement'],['multicore','Require shared multicore; fail if isolation is unavailable']]);
  if(!document.getElementById('nativeWorkers'))number('workers','CPU lanes (0 = automatic)',0,32);
  choice('bits','WASM addressing',[['auto','Automatic: 32-bit unless the budget needs memory64'],['32','32-bit'],['64','64-bit, with capability fallback']]);
  check('spill','Store the basis and degree checkpoints in OPFS');
  check('resume','Reuse the matching algebra checkpoint');
  check('hilbert','Compute exact Hilbert coefficients');
  const pruneOriginal=document.getElementById('monomialPruning');
  if(!pruneOriginal)check('monomialPruning','Prune consequences of monomial zero relations');
  const details=document.createElement('details');const summary=document.createElement('summary');summary.textContent='Advanced tuning';details.append(summary);box.append(details);
  check('heapReduction','Fast sparse heap reduction for short words',details);
  number('cachePercent','Reducer cache (% of each lane workspace)',0,40,details);
  number('heapThreshold','Heap reduction minimum term count',1,1048576,details);
  number('batchPairs','Critical pairs per batch (blank = auto; 0 = low-memory scheduler)',0,512,details);
  number('hashBits','Lookup hash bits',8,26,details);
  number('scratchMiB','Total reduction workspace, MiB (blank = automatic)',1,14303,details);
  number('hilbertMiB','Additional Hilbert workspace, MiB',0,14304,details);
  choice('ioMode','Parallel file I/O',[['auto','Automatic: probe concurrent handles, otherwise broker'],['broker','Portable: one exclusive OPFS owner'],['direct','Prefer direct concurrent handles; broker if unsupported']],details);
  const note=document.createElement('p');note.textContent='Leave George’s maximal degree blank for completion without a user degree bound. Homogeneous relations, unit weights, Q or a prime field and degleftlex are supported. Reversing the generator order, timeout and memory controls remain in the main form. Low-terms quick/safe are equivalent for homogeneous input. Rabbit, resolutions and weighted orders are not implemented. Save unsaved input before enabling isolation, which may reload this page.';box.append(note);
  const pruneNote=document.createElement('p');pruneNote.textContent='For fomkyr, “monomial pruning” means exact zero-word shortcuts, not Bergman’s Lisp monomial-storage garbage collection. Both settings produce the same algebra; disabling shortcuts is useful for cross-checks.';box.append(pruneNote);
  const status=document.createElement('pre');status.id='fomkyr-runtime-status';status.style.whiteSpace='pre-wrap';
  function button(text,fn){const b=document.createElement('button');b.type='button';b.textContent=text;b.onclick=async()=>{try{await fn();}catch(e){status.textContent=e.message;}};box.append(b);return b;}
  button('Inspect browser capabilities',()=>{status.textContent=JSON.stringify(browserCapabilities(),null,2);});
  button('Enable static-host multicore (one reload)',async()=>{
    const projectRoot=new URL('../../',import.meta.url);
    // Recent George versions already own an isolation worker. Never replace it.
    status.textContent=JSON.stringify(await requestIsolation({workerURL:new URL('fomkyr-isolation-worker.js',projectRoot),scope:projectRoot}),null,2);
  });
  button('Request persistent browser storage',async()=>{status.textContent=JSON.stringify(await requestPersistentStorage(),null,2);});
  const entries=document.createElement('div');
  button('Show cached algebras',async()=>{
    entries.replaceChildren();const runs=await listCachedRuns();status.textContent=`${runs.length} cached run(s). Active runs cannot be deleted.`;
    for(const r of runs){const row=document.createElement('p');row.textContent=`${r.key}: degree ${r.completedThroughDegree??'unverified'}, ${r.diskBytes} bytes `;
      const del=document.createElement('button');del.type='button';del.textContent='Delete this cache';del.onclick=async()=>{if(!confirm(`Delete cached algebra ${r.key}?`))return;try{await deleteCachedRun(r.key);row.remove();}catch(e){status.textContent=e.message;}};row.append(del);entries.append(row);}
  });
  box.append(status,entries);select.parentElement.insertAdjacentElement('afterend',box);
  const originalTitles=new Map();
  function update(){
    const active=select.value==='fomkyr';box.hidden=!active;
    const workers=document.getElementById('nativeWorkers');if(active&&workers){workers.disabled=false;workers.closest('[hidden]')?.removeAttribute('hidden');}
    if(pruneOriginal){if(!originalTitles.has(pruneOriginal))originalTitles.set(pruneOriginal,pruneOriginal.title);if(active){pruneOriginal.disabled=false;pruneOriginal.title='fomkyr: exact monomial-zero reduction and pair shortcuts (not Lisp garbage collection).';}else pruneOriginal.title=originalTitles.get(pruneOriginal);}
    const max=document.getElementById('maxdeg');if(active&&max){max.removeAttribute('max');max.placeholder='none: complete until stopped or proved';}
    const memory=document.getElementById('memoryMiB');
    if(active&&memory){for(const o of memory.options)o.disabled=Number(o.value)>14304||Number(o.value)<16;if(Number(memory.value)>14304||Number(memory.value)<16){if([...memory.options].some(o=>o.value==='14304'))memory.value='14304';else memory.value='2048';}}
    else if(memory)for(const o of memory.options)o.disabled=false;
    if(active)status.textContent=`${globalThis.crossOriginIsolated?'Isolation available: shared multicore can be selected.':'No isolation: automatic mode will use the unshared single-worker build.'} Actual bitness, worker count and I/O fallbacks are reported for each run.`;
  }
  select.addEventListener('change',()=>queueMicrotask(update));update();
}
if(typeof document!=='undefined'){
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',installFomkyrControls,{once:true});else installFomkyrControls();
}
