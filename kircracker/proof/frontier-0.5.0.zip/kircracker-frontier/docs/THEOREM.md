# One degree-14 element controls the FK6/Nichols fork through degree 16

This is a theorem-dependent exact computational argument. It is not a claim of a
peer-reviewed result, a proof-assistant formalization, priority, or a decision of
FK6 finite/infinite dimensionality. The explicit polynomial is in
`certificates/nichols/degree14-radical.json`. It has 134 terms, coefficients +/-1,
ordinary degree 14, and identity S6 degree. Call its class **Q**.

## 1. Distinguish the two algebras

Let E be the original quadratic Fomin-Kirillov algebra over Q, and B its transposition
Nichols quotient. The canonical map pi:E->B is a graded braided Hopf quotient; its
kernel K is the radical of the standard scalar braided pairing. This relationship
is stated in BLM Conjecture 3.7 and the accompanying explanation [1]. B is not
identified with E in this work.

For A, the five-edge star in E, use ai=x_i6. Let H be its four-edge substar on
leaves1..4, and F the FK5 algebra on vertices1..5. Let C be the image of A in B.
Known finite H and F survive injectively in B: their nondegenerate pairings in
rank<=5 are restrictions of the ambient pairing. Their dimensions and multiplication
models are recomputed from exact derivative images using the published finite
Hilbert series as upper bounds.

## 2. Why the finite-factor argument applies in B

It is NOT valid simply to transport any tensor decomposition through any quotient.
Here the original proof's hypotheses survive, as follows.

The images of edge subalgebras are graded left coideal subalgebras of B. For nested
images H subset C, repeat BLM Theorem 4.1's elementary coproduct proof. Choose a
homogeneous section of C/H^+C. Multiplication H tensor (C/H^+C)->C is surjective by
induction. In a putative relation, choose a nonzero coefficient with minimum H-degree.
Apply a graded-dual functional selecting that coefficient to the first coproduct
factor and project the second factor to C/H^+C. Terms whose second H-factor is
positive disappear. Minimum degree leaves precisely the supposed quotient relation,
a contradiction. Hence multiplication is an isomorphism. Graded dual functionals
may be extended linearly inside B because all individual degree spaces are finite.
No pairing nondegeneracy of original FK6 is assumed in this step.

Ordinary word reversal also descends to B; this needs justification rather than
silently assuming a quotient inherits every map. Let S_d be the quantum symmetrizer
on tensor words, J ordinary reversal, and T_i the signed permutation braid matrices.
The local FK braiding satisfies J T_i J=T_(d-i)^(-1). It follows that
J S_d J=S_d^T. For the positive lift Delta of the longest symmetric-group element,
length-additive factorization gives S_d^T=Delta^(-1) S_d. Hence ker S_d^T=ker S_d,
and J preserves ker S_d. Reversal therefore preserves the Nichols ideal and gives
an ordinary opposite-algebra isomorphism. This supplies the right-hand version of
the coideal-freeness proof and justifies reversing the relative basis words. The
exact matrix identities are tested independently in word degrees2,3,4; the stated
braid argument establishes the identity in all degrees.

The support-partition grading also descends to B. A generator braid sends a pair
(e,f) to (s_e(f),e), up to sign, preserving its connected support partition. Thus
all braid operators and the quantum symmetrizer preserve support partitions, and
so does their kernel. The package checks all225 two-edge possibilities in S6; the
same observation proves preservation by any product of such operators.

Now repeat BLM Theorem 4.8: the original quadratic crossings move every leaf-leaf
edge to the right of star edges, giving a surjection C tensor F->B. Freeness and
support partitions prove injection: a nonzero element supported on vertices1..5
cannot lie in the ideal with a star-edge component involving vertex6. Consequently

    B ~= C tensor F ~= H tensor M_B tensor F,
    M_B = C/H^+C,

as graded vector spaces. All maps respect S6 product grading. This is not an
ordinary tensor-product algebra assertion. Reversal supplies the equivalent left
coset convention used by the complementary pairing.

The old complementary minors are still lower bounds for M_B: the full pairing
annihilates K and the appropriate quotient boundary. A dependence after passing to
B would therefore contradict the replayed nonzero determinant. This is why the
old finite-factor lower evidence also proves E_d=B_d through degree13 once the
independent original-E upper calculation matches it.

## 3. The computed relation and the Nichols upper bound

An exact derivative-DAG calculation proves **pi(Q)=0**. This is stronger than the
old selected853 complementary functionals vanishing: EVERY full ambient scalar
derivative chain vanishes. See `radical.py` and the two independent replays.

The upper calculation adds all120 distinct leaf-S5 images of Q to the previously
proved929 original-FK identities. Each added relation is justified in B, not in E.
They define an integral presented upper model for M_B. Specialization to F2 can
only raise its degree dimensions relative to Q. The original-pairing lower minors
are independently checked over the integers and reduced modulo1,000,003 only to
certify nonzero determinants.

The lower and upper dimensions agree through16:

    M_B: ..., m13=29180, m14=56856, m15=109262, m16=207276.

The graded finite-factor multiplication above then gives exactly

    dim B14 =   346652739,
    dim B15 =   850296015,
    dim B16 =  2031123359.

Every product-permutation component closes as well. None of these is silently
relabeled an exact original-FK dimension. The module builder's generic raw log says
“FK upper bound after library proof”; that generic description does NOT apply to
this separately typed Nichols library. The wrapper and output claims correct the
scope explicitly, and the original FK library verifier rejects the new inference.

## 4. Low-degree equality and the minimal Hopf kernel

The same recomputation verifies K_d=0 for d<14. The original FK intervals, minus
the exact Nichols dimensions, give

    dim K14 <= 1,
    dim K15 <= 15,
    dim K16 <= 125.

The inequalities hold componentwise, with the gap character exactly the degree0,
1,2 character shifted by14. This finite graded identity is checked by `fork.py`.
It is not an assumed rational function for the infinite Hilbert series.

Since pi is a graded coalgebra map and K has no component of degree<14, the reduced
coproduct of a degree14 element of K is zero: every bidegree(i,14-i), 1<=i<=13,
maps injectively under pi tensor pi. In particular

    Delta(Q)=Q tensor1 + 1 tensor Q.

This includes the possibility Q=0. It is NOT a nonzero primitive-element claim.

## 5. Branch A: Q is zero in original E

If Q=0 in E, every added permutation image is also an original-E relation. The same
presented upper model becomes a legitimate upper model for original M. Its dimensions
already match the independent lower minors. Thus, through degree16, E=B and

    (h14,h15,h16)=(346652739,850296015,2031123359).

This would decide these finite degrees only. It would not prove E finite or E=B in
all degrees. A proof of Q=0 must be a genuine original-ideal membership argument;
full-pairing radical membership is insufficient.

## 6. Branch B: Q is nonzero in original E

Then Q is a nonzero primitive with identity permutation degree. Its self-braiding
is the ordinary flip. If m were the least positive exponent with Q^m=0, the bidegree
(14,14(m-1)) component of Delta(Q^m) would be

    m Q tensor Q^(m-1),

which is nonzero in characteristic zero. This contradiction shows all Q^m are nonzero.
Their distinct ordinary degrees make them independent. Hence E is infinite-dimensional.
This conclusion is conditional on the currently missing proof that Q!=0 in E.

More concretely, right multiplication by Q is injective on E_k for k<14. Indeed,
Q nabla_e=0 since it lies in K13=0 after a first derivative. Its identity permutation
degree makes the right Leibniz rule

    (YQ) nabla_e = (Y nabla_e)Q.

For nonzero Y in E_k, k<14, nondegeneracy of that degree's pairing supplies a scalar
chain ending in a nonzero multiple of Q. Thus YQ cannot be zero. For k=0,1,2 this
places independent spaces of dimensions1,15,125 inside K14,K15,K16. Their previously
checked upper bounds force equality. Therefore

    (h14,h15,h16)=(346652740,850296030,2031123484).

This rules out four of the old six standalone possibilities for h16 without deciding
which of the remaining two occurs. The three choices are linked, not independent.

## 7. What exactly remains open

One exact membership question now decides the three degrees jointly:

    Is the supplied134-term Q in the original quadratic FK ideal?

A zero reduction using any rigorously valid original-ideal reducers would prove
Branch A. A nonzero normal form requires a fully certified degree14 basis (or some
other independent nonvanishing argument) to prove Branch B. A nonzero remainder
under an incomplete basis, or mere agreement with a published Hilbert scalar,
proves neither branch.

This is not a discovery of a nonzero Nichols-kernel element in FK6: it is a discovered
free-polynomial representative whose image in FK6 may still be zero. The completed
Nichols calculation and conditional theorem do not settle FK6/Nichols equality or
FK6 infinitude. No priority or author-confirmed status is claimed.

## Primary reference

[1] J. Blasiak, R. I. Liu, K. Meszaros, *Subalgebras of the Fomin-Kirillov algebra*,
arXiv:1310.4112v2, Propositions3.1,3.2,3.5, Conjecture3.7 explanation, Lemma3.10,
Theorem4.1 and Theorem4.8/Corollary4.9. https://arxiv.org/html/1310.4112v2

Section2's extension of the proof to the Nichols quotient and the one-element fork
are arguments of this report, not assertions quoted as established results from [1].
