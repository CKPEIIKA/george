/* SPDX-License-Identifier: MIT
 * Original implementation, not a translation of Bergman or Singular.
 * No malloc, GC, C++ runtime, MEMFS, unbounded pair queue, or floating point algebra.
 */
#include "kernel.h"
#include "../fk_gate/src/fk_gate.h"
#include "../fk_gate/profiles/fk6_sectors.h"
#define PAGE_N 1024u
#ifdef GN_SINGLE
#define GN_ATOMIC(T) T
#define GN_LOAD(p) (*(p))
#define GN_STORE(p,v) (*(p)=(v))
#define GN_FETCH_ADD(p,v) ((*(p))+=(v),(*(p))-(v))
#define GN_TRY_LOCK(p) ((*(p))?0:((*(p))=1,1))
#define GN_UNLOCK(p) ((*(p))=0)
#else
#include <stdatomic.h>
#define GN_ATOMIC(T) _Atomic(T)
#define GN_LOAD(p) atomic_load_explicit(p,memory_order_relaxed)
#define GN_STORE(p,v) atomic_store_explicit(p,v,memory_order_relaxed)
#define GN_FETCH_ADD(p,v) atomic_fetch_add_explicit(p,v,memory_order_relaxed)
static int try_lock(_Atomic(u32)*p){u32 expected=0;return atomic_compare_exchange_strong_explicit(p,&expected,1,memory_order_acquire,memory_order_relaxed);}
#define GN_TRY_LOCK(p) try_lock(p)
#define GN_UNLOCK(p) atomic_store_explicit(p,0,memory_order_release)
#endif
#define WORD_LONG (UINT64_C(1)<<63)
#define BATCH_MAX 512u
#define RED_CACHE_N 256u
#define GN_RESUME_SLOTS (2u*GN_MAX_WORKERS+1u)
#define GN_RESERVE_SLOTS (GN_MAX_WORKERS+1u)
#define SMALL_MAX INT64_C(4611686018427387903)
#define MAGIC UINT32_C(0x31424e47)
#define STACK_BYTES (128u*1024u)
#define A8(x) (((x)+7u)&~UINT64_C(7))
#define MIN(a,b) ((a)<(b)?(a):(b))
#define MAX(a,b) ((a)>(b)?(a):(b))
typedef struct {u64 lo,hi;} Word;
typedef u64 Coef; /* even: signed 63-bit immediate; odd: offset|1|signbit(2) */
typedef struct {Word w; Coef c;} Term;
typedef struct {u64 base,pos,end,peak;u32 error;} Arena;
typedef struct {u64 off;u32 n,degree;u64 origin;} Poly;
typedef struct {Word lm;u64 location;u32 bytes,n,degree,next;u64 pinned,tail_cache;u32 tail_snapshot,tail_generation,tail_tried;} Rule;
typedef struct {u32 rule,next;u32 length,pad;} Prefix;
typedef struct {u32 magic,bytes,n,degree;u64 checksum,reserved;} Record;
typedef struct {u32 id,bytes;u64 offset;} Cache;
typedef struct {Word w;u32 version,degree,id,pos;} RedCache;
typedef struct {
  Arena a[2]; u64 io_base,io_size,cache_base,cache_slot;
  u64 io_extra_base,io_extra_bytes;
  u64 out_base,out_size,out_used;
  u64 cache_data,cache_capacity,cache_used,cache_hits;
  u32 cache_epoch,cache_mask; RedCache red[RED_CACHE_N];
  Poly result;u32 f,g,k,snapshot,error,active;
  /* Provenance of a COMPLETE worker normal form, never a parked partial row. */
  u32 normal_valid,normal_snapshot,normal_degree,delta_floor;
  u64 delta_queries,delta_hits,delta_probes;
  u32 slice_enabled,resume_tier,resume_capacity,reserve_retry,resume_slot,no_reserve,reserve_waiting; double slice_end;
  Arena reserve_saved; GN_ATOMIC(u64) slice_yields,slice_resumes;
  u32 memory_wait,is_commit,reserve_direct,output_extra_index,memory_detail,coefficient_extra_slot,coefficient_extra_retired,output_extra_retired;u64 memory_need,row_growths;
  u64 coefficient_extra_base,coefficient_extra_bytes;
  u64 row_workspace_bytes,memory_live_bytes,memory_minimum_bytes;u32 row_layout_attempted;
  Arena output_saved;u64 output_extra_base,output_extra_bytes;
  u64 out_original_base,out_original_size,out_extra_base,out_extra_bytes;
  u64 reductions,pruned,reads,read_bytes,pairs,peak;
  u64 hash_probes,matcher_queries,matcher_characters,redcache_hits,heap_attempts,heap_successes,heap_fallbacks;
  u64 insertion_prunes,commuting_prunes,quadratic_swaps;
  u64 reserve_attempts,reserve_successes,reserve_busy,reserve_misses,reserve_peak,reserve_promotions;u32 reserve_owned,reserve_slot;
  u64 row_relayouts;
  u32 allow_repack;u32 rational_maxed,rational_full_capacity;u64 rational_table_growths;u64 big_attempts,big_successes,big_fallbacks,big_steps,big_compactions,big_pool_misses,big_capacity_misses,big_arena_misses;
  u64 big_growths,big_peak_terms,big_capacity,big_reserved,big_coefficient_live,big_coefficient_bytes,big_reserve_waits,general_fallbacks;
  u64 big_pool_high_water,big_arithmetic_high_water,big_collected_live_high_water;
  u64 rational_attempts,rational_successes,rational_fallbacks,integer_steps,rational_steps,local_hits,pinned_hits;u64 rational_local_hits,rational_space_misses,rational_coefficient_misses,rational_arithmetic_misses,rational_table_retries;u32 publications,busy,skip_rule,reduction_tier,tail_generation,tail_snapshot;
} Lane;
typedef struct {u32 f,g,k,snapshot,rc,bytes;u64 output;} BatchTask;
/* Published at sparse safe points, never read another lane's mutable row. */
typedef struct __attribute__((aligned(64))) {
 GN_ATOMIC(u64) reductions,pruned,reads,pairs,terms,hash_probes,matcher_queries;
 GN_ATOMIC(u32) busy,sequence;
 GN_ATOMIC(u64) tier,exact_fallbacks,left_rule,right_rule,overlap;
 GN_ATOMIC(u64) big_growths,big_peak_terms,big_capacity,big_reserved,big_coefficient_live,big_coefficient_bytes,big_capacity_misses,big_pool_misses,big_arena_misses,big_fallbacks,big_reserve_waits;
 GN_ATOMIC(u64) big_pool_high_water,big_arithmetic_high_water,big_collected_live_high_water;
  GN_ATOMIC(u64) memory_wait,memory_need,row_growths;
  GN_ATOMIC(u64) memory_detail,row_workspace_bytes,memory_live_bytes,memory_minimum_bytes,row_relayouts;
} LiveLane;

typedef struct {
  FkgGate fgate;
  u32 fg_sector_enabled,fg_sector_ready,fg_closed,fg_sector_error,fg_sector_nodes;
  u32 fg_external,fg_external_through,fg_external_filled,fg_external_edges;
  u32 fg_edge_map[16];u64 fg_external_base,fg_external_totals;
  u64 fg_sector_upper[360],fg_poll_calls,fg_skipped,fg_recounts,fg_sector_peak;
  GN_ATOMIC(u64) fg_sector_skipped,fg_parked_skipped,fg_commit_skipped;
  double fg_count_ms,fg_sector_ms;
  u64 reserve_base,reserve_bytes,reserve_initial_bytes;u32 reserve_growth,radix_enabled,radix_cache_enabled;
  u32 coop_ms,coop_lookahead;u64 helper_base,helper_bytes;GN_ATOMIC(u32) reserve_lock;
  u64 reserve_extra_base[GN_RESERVE_SLOTS-1];GN_ATOMIC(u32) reserve_extra_lock[GN_RESERVE_SLOTS-1];
  u64 reserve_extra_bytes[GN_RESERVE_SLOTS-1];
  u64 commit_reserve_base,commit_reserve_bytes;GN_ATOMIC(u32) commit_reserve_lock;u32 commit_reserve_configured;
  u64 spare_base[2*GN_RESERVE_SLOTS],spare_bytes[2*GN_RESERVE_SLOTS];u32 spare_count;
  u32 reserve_extra_count,reserve_pool_limit,reserve_pool_denied;GN_ATOMIC(u32) reserve_pool_requested;
  u32 reserve_admission_closed;
  u64 reserve_pool_admissions,reserve_pool_declines;
  GN_ATOMIC(u32) batch_next,batch_running;
  u32 auto_memory,lane_slots,batch_first,batch_committed,batch_work_n;u64 memory_retries,memory_replayed_pairs;
  u32 batch_n,batch_enabled,hilbert_degree,hilbert_nodes;
  u64 batch_epochs,batch_spills,hilbert_bytes;
  u64 hilbert_offset,hilbert_end,hilbert_base;
  u32 hilbert_limbs,pruning,heap_enabled,cache_percent,heap_threshold,rational_enabled,rational_rewrites;
  u32 legacy_big_division,big_rational_enabled,growing_rational,big_row_max_terms;
  u32 delta_commit;
  GN_ATOMIC(u64) commit_metrics[16];
  double deadline;
  BatchTask tasks[BATCH_MAX];
  u32 batch_order[BATCH_MAX],batch_sort[BATCH_MAX],cost_scheduling;
  u64 word_cache_base,word_cache_bytes;u32 word_cache_entries,word_cache_lanes;
  u32 abi,generators,target,workers,modulus,spill,error,completed,current,certifying,canonical_snapshot;
  u64 pin_base,pin_capacity,pin_used;
  u64 local_base,local_capacity,local_used;u32 local_degree,local_built,local_limit,local_snapshot,local_entries,local_declined;
  u32 nrules,nprefix,hash_mask,table_capacity,degree_snapshot;
  u32 iter_f,iter_k,iter_node,iter_ready,iter_done,input_degree,input_expected,input_used;
  GN_ATOMIC(u32) cancel;
  u64 base,bump,budget,scratch_base,scratch_size,stack_base,lm_heads,prefix_heads,rule_pages,prefix_pages;
  u64 disk_end,terms,pair_count,zero_pairs,commit_zero,allocated_peak,largest_rule_bytes;
  u32 matcher_enabled,chain_enabled,telemetry_enabled,matcher_snapshot,gm_mask,gm_requested;
 GN_ATOMIC(u64) gm_examined,gm_skipped[3],gm_unavailable,gm_pending,chain_fallback_queries;
  u32 eager_pruning,quadratic_rewrite,square_mask,commute_mask[16];i64 swap_factor[256];
  u32 matcher_capacity,matcher_nodes,matcher_min,matcher_builds,matcher_fallbacks;
  u64 matcher_base,matcher_limit,matcher_allocated,chain_skipped;
  u64 degree_total,degree_seen,degree_scheduled,degree_committed,degree_monomial,degree_chain;
  u32 degree_total_known,degree_replays;
  u32 gate_active,gate_closed,gate_degree;
  u64 gate_lower,gate_upper,gate_rules,gate_budget,gate_closed_count,gate_skipped,gate_checks,gate_unvisited,gate_pending;
  LiveLane live[GN_MAX_WORKERS];
  Lane lanes[GN_MAX_WORKERS];
} State;
static State S;
#if defined(FOMKYR_TRACE_CORRUPT) && !defined(__wasm__)
/* Optional native error-path tracing; ordinary and Wasm builds incur no cost. */
extern void gn_host_corrupt(const char*,u32,u32,u32);
#define GN_CORRUPT (gn_host_corrupt(__FILE__,__LINE__,S.current,S.nrules),6)
#endif
#define TAIL_REQUESTS 256u
typedef struct {
 u64 base,capacity,used,workspace,workspace_bytes,requested_bytes;
 u32 generation,floor,cursor,building;
 GN_ATOMIC(u32) requests[TAIL_REQUESTS];
 GN_ATOMIC(u64) hits,misses,queued;
 u64 attempts,built,declined,saved_terms,saved_bytes,build_us;
} TailCache;
static TailCache T;
static int tail_cache_prepare(void);
#include "reserve_workspaces.inc"
/* A bounded whole-degree ambiguity plan. Working polynomials remain per-lane. */
typedef struct {u32 f,g,k,ordinal,group;} PlanPair;
typedef struct {
 u32 requested,mode,min_degree,active,anchor_n,count,cursor;
 u32 gate_ready,q14_hint,gate_replans,gate_target,gate_stride;
 u64 base,capacity,allocated,budget,total,anchor_seen,builds,declines,adoptions,build_us,excluded_base,excluded_count;
 u32 excluded_bytes;
 u32 gate_rank[360];u64 gate_pending[360],gate_gap[360],gate_qmass[360],gate_cost[360],gate_injected;
 u32 gate_streak[360];u64 gate_attempts[360],gate_successes[360],gate_cool_until[360],gate_cooldowns;
 u64 gate_last_refresh;u32 gate_degree;
 BatchTask anchor[BATCH_MAX];
} PairPlan;
static PairPlan P;

#ifndef __wasm__
static u8 *native_base;
void gn_bind(void *base){native_base=(u8*)base;}
#define PTR(t,o) ((t*)(native_base+(o)))
#else
#define PTR(t,o) ((t*)(uintptr_t)(o))
extern unsigned char __heap_base;
#endif
#if !defined(__wasm__) && !defined(FOMKYR_BYTE_MEMORY_BASELINE)
/* The POSIX host already links libc. Use its tuned memory routines rather than
 * replacing them process-wide with the freestanding byte-loop fallback. */
#include <string.h>
#else
void *memcpy(void *dst,const void *src,size_t n){u8*d=dst;const u8*s=src;for(size_t i=0;i<n;i++)d[i]=s[i];return dst;}
void *memset(void *dst,int c,size_t n){u8*d=dst;for(size_t i=0;i<n;i++)d[i]=(u8)c;return dst;}
void *memmove(void *dst,const void *src,size_t n){u8*d=dst;const u8*s=src;if(d<s){for(size_t i=0;i<n;i++)d[i]=s[i];}else{while(n){--n;d[n]=s[n];}}return dst;}
#endif
static void publish_lane(Lane*l,u64 terms,u32 force){
 if(!S.telemetry_enabled)return;
 u32 lane=(u32)(l-S.lanes);LiveLane*v=&S.live[lane];
 GN_STORE(&v->reductions,l->reductions);GN_STORE(&v->pruned,l->pruned);
 GN_STORE(&v->reads,l->reads);GN_STORE(&v->pairs,l->pairs);
 GN_STORE(&v->terms,terms);GN_STORE(&v->hash_probes,l->hash_probes);
 GN_STORE(&v->matcher_queries,l->matcher_queries);GN_STORE(&v->busy,l->busy);
 GN_STORE(&v->tier,l->reduction_tier);GN_STORE(&v->exact_fallbacks,l->rational_fallbacks);
 GN_STORE(&v->left_rule,l->f);GN_STORE(&v->right_rule,l->g);GN_STORE(&v->overlap,l->k);
 GN_STORE(&v->big_growths,l->big_growths);GN_STORE(&v->big_peak_terms,l->big_peak_terms);
 GN_STORE(&v->big_capacity,l->big_capacity);GN_STORE(&v->big_reserved,l->big_reserved);
 GN_STORE(&v->big_coefficient_live,l->big_coefficient_live);GN_STORE(&v->big_coefficient_bytes,l->big_coefficient_bytes);
 GN_STORE(&v->big_capacity_misses,l->big_capacity_misses);GN_STORE(&v->big_pool_misses,l->big_pool_misses);
 GN_STORE(&v->big_arena_misses,l->big_arena_misses);GN_STORE(&v->big_fallbacks,l->general_fallbacks);GN_STORE(&v->big_reserve_waits,l->big_reserve_waits);
 GN_STORE(&v->big_pool_high_water,l->big_pool_high_water);GN_STORE(&v->big_arithmetic_high_water,l->big_arithmetic_high_water);GN_STORE(&v->big_collected_live_high_water,l->big_collected_live_high_water);
 GN_STORE(&v->memory_wait,l->memory_wait);GN_STORE(&v->memory_need,l->memory_need);GN_STORE(&v->row_growths,l->row_growths);
 GN_STORE(&v->memory_detail,l->memory_detail);GN_STORE(&v->row_workspace_bytes,l->row_workspace_bytes);GN_STORE(&v->memory_live_bytes,l->memory_live_bytes);GN_STORE(&v->memory_minimum_bytes,l->memory_minimum_bytes);GN_STORE(&v->row_relayouts,l->row_relayouts);
 GN_FETCH_ADD(&v->sequence,1);
 /* The existing clock import can notify the UI while this Wasm call is still
  * running. Only the coordinator invokes its reporting callback. No new ABI
  * import, no row serialization, and no clock call per arithmetic operation. */
 l->publications++;
 if(lane==0 && (force || !(l->publications&7u))) (void)gn_host_clock();
}
static int slice_expired(Lane*l){
 if(!l->slice_enabled)return 0;
 return gn_host_clock()>=l->slice_end;
}
static u32 cancelled(void){
 if(GN_LOAD(&S.cancel))return 1;
 if(S.deadline>0 && gn_host_clock()>=S.deadline){GN_STORE(&S.cancel,1);return 1;}
 return 0;
}
static u64 alloc_a(Arena*a,u64 bytes){bytes=A8(bytes);if(a->error)return 0;if(bytes>a->end-a->pos){a->error=GN_SCRATCH;return 0;}u64 p=a->pos;a->pos+=bytes;if(a->pos-a->base>a->peak)a->peak=a->pos-a->base;return p;}
static void reset_a(Arena*a){a->pos=a->base;a->error=0;}
static u64 alloc_p(u64 bytes){bytes=A8(bytes);u64 p=A8(S.bump);if(S.error||p<S.bump||p>S.budget||bytes>S.budget-p){S.error=GN_MEMORY;return 0;}if(!gn_host_ensure(p+bytes)){S.error=GN_MEMORY;return 0;}S.bump=p+bytes;S.allocated_peak=MAX(S.allocated_peak,S.bump);return p;}
/* <=31 letters: original two-register nibble path. Longer words: bounded
 * byte strings in the same arenas, addressed by offsets (also on memory64).
 * Slices are borrowed; every polynomial/record boundary makes an owned copy. */
static int wlong(Word w){return !!(w.hi&WORD_LONG);}
static Word wresolved(Word w,u64 origin){if(wlong(w))w.lo+=origin;return w;}
static Word pw(Poly p,u32 i){return wresolved(PTR(Term,p.off)[i].w,p.origin);}
static Word shl(Word w,u32 b){if(!b)return w;if(b>=128)return(Word){0,0};if(b>=64)return(Word){0,w.lo<<(b-64)};return(Word){w.lo<<b,(w.hi<<b)|(w.lo>>(64-b))};}
static Word shr(Word w,u32 b){if(!b)return w;if(b>=128)return(Word){0,0};if(b>=64)return(Word){w.hi>>(b-64),0};return(Word){(w.lo>>b)|(w.hi<<(64-b)),w.hi>>b};}
static Word maskw(Word w,u32 n){u32 b=4*n;if(!b)return(Word){0,0};if(b>=128)return w;if(b<64)return(Word){w.lo&((UINT64_C(1)<<b)-1),0};if(b==64)return(Word){w.lo,0};return(Word){w.lo,w.hi&((UINT64_C(1)<<(b-64))-1)};}
static u8 letter(Word w,u32 n,u32 pos){return wlong(w)?PTR(u8,w.lo)[pos]:(u8)(shr(w,4*(n-pos-1)).lo&15);}
static Word part(Word w,u32 n,u32 pos,u32 len){
 if(!len)return(Word){0,0};
 if(!wlong(w))return maskw(shr(w,4*(n-pos-len)),len);
 if(len>GN_INLINE_DEGREE)return(Word){w.lo+pos,WORD_LONG|len};
 Word r={0,0};for(u32 i=0;i<len;i++){r=shl(r,4);r.lo|=PTR(u8,w.lo)[pos+i];}return r;
}
static Word shortcat(Word a,Word b,u32 nb){Word w=shl(a,4*nb);return(Word){w.lo|b.lo,w.hi|b.hi};}
static Word clonew(Arena*a,Word w,u32 n){if(!wlong(w))return w;u64 off=alloc_a(a,n);if(!off)return(Word){0,0};memcpy(PTR(u8,off),PTR(u8,w.lo),n);return(Word){off,WORD_LONG|n};}
static Word context(Word l,Word w,u32 nw,Word r,u32 nr,u32 degree,Arena*a){
 if(degree<=GN_INLINE_DEGREE)return shortcat(shortcat(l,w,nw),r,nr);
 u32 nl=degree-nw-nr;u64 off=alloc_a(a,degree);if(!off)return(Word){0,0};u8*out=PTR(u8,off);
 for(u32 i=0;i<nl;i++)out[i]=letter(l,nl,i);
 for(u32 i=0;i<nw;i++)out[nl+i]=letter(w,nw,i);
 for(u32 i=0;i<nr;i++)out[nl+nw+i]=letter(r,nr,i);
 return(Word){off,WORD_LONG|degree};
}
static int weq(Word a,Word b){
 if(!wlong(a)&&!wlong(b))return a.lo==b.lo&&a.hi==b.hi;
 if(a.hi!=b.hi)return 0;if(a.lo==b.lo)return 1;
 u32 n=(u32)a.hi;for(u32 i=0;i<n;i++)if(PTR(u8,a.lo)[i]!=PTR(u8,b.lo)[i])return 0;return 1;
}
static int wcmp(Word a,Word b){
 if(!wlong(a)&&!wlong(b))return a.hi!=b.hi?(a.hi>b.hi?1:-1):a.lo!=b.lo?(a.lo>b.lo?1:-1):0;
 if(!wlong(a)||!wlong(b))return wlong(a)?1:-1;
 u32 na=(u32)a.hi,nb=(u32)b.hi;
 if(na!=nb)return na>nb?1:-1;
 for(u32 i=0;i<na;i++){u8 x=PTR(u8,a.lo)[i],y=PTR(u8,b.lo)[i];if(x!=y)return x>y?1:-1;}return 0;
}
static u64 mix(u64 x){x^=x>>30;x*=UINT64_C(0xbf58476d1ce4e5b9);x^=x>>27;x*=UINT64_C(0x94d049bb133111eb);return x^(x>>31);}
static u32 hash(Word w,u32 n){
 if(!wlong(w))return(u32)mix(w.lo^mix(w.hi+((u64)n<<32)))&S.hash_mask;
 u64 h=UINT64_C(1469598103934665603);for(u32 i=0;i<n;i++){h^=PTR(u8,w.lo)[i];h*=UINT64_C(1099511628211);}return(u32)mix(h^n)&S.hash_mask;
}
static u32 prefix_hash(Word w,u32 length,u32 full_degree){
 return (hash(w,length)^(u32)mix((u64)full_degree+UINT64_C(0x9e3779b97f4a7c15)))&S.hash_mask;
}
static Rule *rule(u32 id){u64 page=PTR(u64,S.rule_pages)[(id-1)/PAGE_N];return PTR(Rule,page)+((id-1)%PAGE_N);}
static Prefix *prefix(u32 id){u64 page=PTR(u64,S.prefix_pages)[(id-1)/PAGE_N];return PTR(Prefix,page)+((id-1)%PAGE_N);}
static u64 c_bigoff(Coef c){return c&~UINT64_C(7);}
static int csign(Coef c){return c&1?(c&2?-1:1):((i64)c<0?-1:c?1:0);}
static Coef csmall(i64 x){return ((u64)x)<<1;}
static i64 cvalue(Coef c){return ((i64)c)>>1;}
static u64 cabs64(Coef c){i64 v=cvalue(c);return v<0?(u64)(-v):(u64)v;}
static Coef cneg(Coef c){return c&1?c^2:csmall(-cvalue(c));}
static Coef cabs(Coef c){return csign(c)<0?cneg(c):c;}
static u32 cn(Coef c){if(c&1)return*PTR(u32,c_bigoff(c));u64 v=cabs64(c);return v>>32?2:v?1:0;}
static u32 cl(Coef c,u32 i){if(c&1)return i<cn(c)?PTR(u32,c_bigoff(c)+8)[i]:0;u64 v=cabs64(c);return i<2?(u32)(v>>(32*i)):0;}
static Coef resolved(Coef c,u64 origin){return c&1?(c_bigoff(c)+origin)|(c&7):c;}
static Coef pc(Poly p,u32 i){return resolved(PTR(Term,p.off)[i].c,p.origin);}
static Coef makec(Arena*a,const u32*v,u32 n,int sign){while(n&&!v[n-1])--n;if(!n)return 0;if(n<=2){u64 z=v[0]|(n==2?(u64)v[1]<<32:0);if(z<=(u64)SMALL_MAX)return csmall(sign<0?-(i64)z:(i64)z);}u64 off=alloc_a(a,8+(u64)n*4);if(!off)return 0;PTR(u32,off)[0]=n;PTR(u32,off)[1]=0;memcpy(PTR(u32,off+8),v,(size_t)n*4);return off|1|(sign<0?2:0);}
static Coef clonec(Arena*a,Coef c){if(!(c&1))return c;return makec(a,PTR(u32,c_bigoff(c)+8),cn(c),csign(c));}
static int magcmp(Coef a,Coef b){u32 na=cn(a),nb=cn(b);if(na!=nb)return na>nb?1:-1;for(u32 i=na;i;i--){u32 x=cl(a,i-1),y=cl(b,i-1);if(x!=y)return x>y?1:-1;}return 0;}
static Coef addc_base(Arena*z,Coef a,Coef b){
 if(z->error)return 0;
 if(!a)return clonec(z,b);if(!b)return clonec(z,a);
 if(!(a&1)&&!(b&1)){i64 x=cvalue(a)+cvalue(b);if(x>=-SMALL_MAX&&x<=SMALL_MAX)return csmall(x);}
 int sa=csign(a),sb=csign(b),sg=sa;u32 n=MAX(cn(a),cn(b));u64 off=alloc_a(z,4*(u64)(n+1));if(!off)return 0;u32*v=PTR(u32,off);
 if(sa==sb){u64 carry=0;for(u32 i=0;i<n;i++){u64 q=(u64)cl(a,i)+cl(b,i)+carry;v[i]=(u32)q;carry=q>>32;}v[n++]=(u32)carry;}
 else{int cmp=magcmp(a,b);if(!cmp)return 0;if(cmp<0){Coef q=a;a=b;b=q;sg=sb;}u64 borrow=0;for(u32 i=0;i<n;i++){u64 x=cl(a,i),y=(u64)cl(b,i)+borrow;v[i]=(u32)(x-y);borrow=x<y;} }
 return makec(z,v,n,sg);
}
static Coef mulc_base(Arena*z,Coef a,Coef b){
 if(z->error)return 0;
 if(!a||!b)return 0;if(a==csmall(1))return clonec(z,b);if(b==csmall(1))return clonec(z,a);
 if(a==csmall(-1))return cneg(clonec(z,b));if(b==csmall(-1))return cneg(clonec(z,a));
 if(!(a&1)&&!(b&1)){u64 x=cabs64(a),y=cabs64(b);if(x<=(u64)SMALL_MAX/y)return csmall((csign(a)*csign(b))*(i64)(x*y));}
 u32 na=cn(a),nb=cn(b);u64 off=alloc_a(z,4*(u64)(na+nb));if(!off)return 0;u32*v=PTR(u32,off);memset(v,0,4*(size_t)(na+nb));
 for(u32 i=0;i<na;i++){if((u64)na*nb>16384&&!(i&15)&&cancelled()){z->error=GN_CANCELLED;return 0;}u64 carry=0;for(u32 j=0;j<nb;j++){u64 q=(u64)cl(a,i)*cl(b,j)+v[i+j]+carry;v[i+j]=(u32)q;carry=q>>32;}v[i+nb]=(u32)carry;}
 return makec(z,v,na+nb,csign(a)*csign(b));
}
#include "integer_limbs.inc"
static Coef legacy_divmodc(Arena*z,Coef a,Coef b,int quotient){
 if(!b){z->error=GN_CORRUPT;return 0;}if(!(a&1)&&!(b&1)){u64 x=cabs64(a),y=cabs64(b);return csmall((i64)(quotient?x/y:x%y));}
 if(magcmp(a,b)<0)return quotient?0:clonec(z,cabs(a));
 u32 na=cn(a),nb=cn(b);u64 ro=alloc_a(z,4*(u64)(nb+1)),qo=quotient?alloc_a(z,4*(u64)na):0;if(!ro||(quotient&&!qo))return 0;
 u32*r=PTR(u32,ro),*q=quotient?PTR(u32,qo):0;memset(r,0,4*(size_t)(nb+1));if(q)memset(q,0,4*(size_t)na);
 for(u64 bit=(u64)na*32;bit;){--bit;u32 carry=(cl(a,(u32)(bit/32))>>(bit%32))&1;
  for(u32 j=0;j<=nb;j++){u32 next=r[j]>>31;r[j]=(r[j]<<1)|carry;carry=next;}
  int cmp=r[nb]?1:0;if(!cmp){for(u32 j=nb;j;j--){u32 v=cl(b,j-1);if(r[j-1]!=v){cmp=r[j-1]>v?1:-1;break;}}}
  if(cmp>=0){u64 borrow=0;for(u32 j=0;j<nb;j++){u64 x=r[j],y=(u64)cl(b,j)+borrow;r[j]=(u32)(x-y);borrow=x<y;}r[nb]-=(u32)borrow;if(q)q[bit/32]|=(u32)1<<(bit%32);}
 }
 return quotient?makec(z,q,na,1):makec(z,r,nb+1,1);
}
/* Release 0.6.2: normalized base-2^32 long division. All estimates and
 * corrections are integer operations. The original bitwise divider remains
 * available for differential testing and optional conservative execution. */
static Coef compactc(Arena*z,u64 mark,Coef c){
 if(z->error)return 0;
 if(!(c&1)){z->pos=mark;return c;}
 u64 off=c_bigoff(c),bytes=A8(8+(u64)cn(c)*4);
 if(off<mark)return c; /* a borrowed operand; normally callers clone it */
 memmove(PTR(u8,mark),PTR(u8,off),(size_t)bytes);z->pos=mark+bytes;
 return mark|(c&7);
}
#include "limb_division.inc"
static Coef divmodc(Arena*z,Coef a,Coef b,int quotient){
 if(z->error)return 0;
 if(S.legacy_big_division)return legacy_divmodc(z,a,b,quotient);
 u64 mark=z->pos;Coef c=limb_divmodc(z,a,b,quotient);return compactc(z,mark,c);
}
/* Euclidean remainders occupy two reusable slots. The previous implementation
 * retained every remainder in a bump arena, a quadratic-space scratch failure
 * on long exact coefficients despite a tiny live polynomial. */
static Coef gcd_slot(u64 off,Coef c){
 if(!(c&1))return c;u64 bytes=8+(u64)cn(c)*4;
 memmove(PTR(u8,off),PTR(u8,c_bigoff(c)),(size_t)bytes);return off|1;
}
static Coef gcdc_euclid(Arena*z,Coef a,Coef b){
 if(z->error)return 0;u64 mark=z->pos;a=cabs(a);b=cabs(b);
 if(a==2||b==2)return 2;
 if(!a)return clonec(z,b);if(!b)return clonec(z,a);
 if(!(a&1)&&!(b&1)){u64 x=cabs64(a),y=cabs64(b);while(y){u64 r=x%y;x=y;y=r;}return csmall((i64)x);}
 u32 n=MAX(cn(a),cn(b));u64 bytes=A8(8+(u64)n*4);
 u64 slot[2]={alloc_a(z,bytes),alloc_a(z,bytes)};if(z->error)return 0;
 a=gcd_slot(slot[0],a);b=gcd_slot(slot[1],b);u64 work=z->pos;u32 turn=0,rounds=0;
 while(b&&!z->error){
  if((++rounds&127)==0&&cancelled()){z->error=GN_CANCELLED;return 0;}
  if(!(a&1)&&!(b&1)){u64 x=cabs64(a),y=cabs64(b);while(y){u64 r=x%y;x=y;y=r;}a=csmall((i64)x);break;}
  z->pos=work;Coef r=divmodc(z,a,b,0);if(z->error)return 0;
  r=gcd_slot(slot[turn],r);a=b;b=r;turn^=1;
 }
 z->pos=work;return compactc(z,mark,clonec(z,a));
}
#include "integer_gcd.inc"
static Coef exactdiv_base(Arena*z,Coef a,Coef b){if(z->error)return 0;if(!a)return 0;if(b==2)return clonec(z,a);Coef q=divmodc(z,a,b,1);return csign(a)*csign(b)<0?cneg(q):q;}
#include "integer_exact_division.inc"
static u32 fpow(u32 a,u32 b){u64 r=1;while(b){if(b&1)r=r*a%S.modulus;a=(u32)((u64)a*a%S.modulus);b>>=1;}return(u32)r;}
static Coef addf(Arena*a,Coef x,Coef y){return S.modulus?csmall((cvalue(x)+cvalue(y))%S.modulus):addc(a,x,y);}
static Coef mulf(Arena*a,Coef x,Coef y){return S.modulus?csmall((i64)((u64)cvalue(x)*(u64)cvalue(y)%S.modulus)):mulc(a,x,y);}
static Coef negf(Coef c){return S.modulus?(c?csmall(S.modulus-cvalue(c)):0):cneg(c);}
static int normalise(Poly*p,Arena*a){if(!p->n)return 0;Term*t=PTR(Term,p->off);Coef lead=pc(*p,0);
 if(S.modulus){u32 inv=fpow((u32)cvalue(lead),S.modulus-2);for(u32 i=0;i<p->n;i++)t[i].c=csmall((i64)((u64)cvalue(pc(*p,i))*inv%S.modulus));p->origin=0;return 0;}
 Coef g=cabs(lead);for(u32 i=1;i<p->n&&g!=2&&!a->error;i++)g=gcdc(a,g,pc(*p,i));int sign=csign(lead);
 if(g!=2||p->origin){for(u32 i=0;i<p->n;i++){Coef c=exactdiv(a,pc(*p,i),g);t[i].c=sign<0?cneg(c):c;}}
 else if(sign<0){for(u32 i=0;i<p->n;i++)t[i].c=cneg(t[i].c);}p->origin=0;return a->error;
}
static u64 checksum(u64 off,u32 n){const u8*p=PTR(u8,off);u64 h=UINT64_C(1469598103934665603);for(u32 i=0;i<n;i++){h^=p[i];h*=UINT64_C(1099511628211);}return h;}
static u64 record_bytes(Poly p){u64 n=sizeof(Record)+(u64)p.n*sizeof(Term);for(u32 i=0;i<p.n;i++){Coef c=pc(p,i);if(c&1)n+=A8(8+(u64)cn(c)*4);if(p.degree>GN_INLINE_DEGREE)n+=A8(p.degree);}return A8(n);}
static int write_record(Poly p,u64 off,u64 cap){u64 size=record_bytes(p);if(size>cap||size>UINT32_MAX)return GN_SCRATCH;Record*h=PTR(Record,off);h->magic=MAGIC;h->bytes=(u32)size;h->n=p.n;h->degree=p.degree;h->reserved=0;u64 cursor=off+sizeof(Record)+(u64)p.n*sizeof(Term);Term*out=PTR(Term,off+sizeof(Record));
 for(u32 i=0;i<p.n;i++){Word w=pw(p,i);out[i].w=w;
  if(wlong(w)){memcpy(PTR(u8,cursor),PTR(u8,w.lo),p.degree);memset(PTR(u8,cursor+p.degree),0,(size_t)(A8(p.degree)-p.degree));out[i].w.lo=cursor-off;cursor+=A8(p.degree);}Coef c=pc(p,i);if(c&1){u64 bytes=8+(u64)cn(c)*4;memcpy(PTR(u8,cursor),PTR(u8,c_bigoff(c)),(size_t)bytes);memset(PTR(u8,cursor+bytes),0,(size_t)(A8(bytes)-bytes));out[i].c=(cursor-off)|(c&7);cursor+=A8(bytes);}else out[i].c=c;}
 if(cursor<off+size)memset(PTR(u8,cursor),0,(size_t)(off+size-cursor));h->checksum=checksum(off+sizeof(Record),(u32)(size-sizeof(Record)));return 0;}
static int validate_record(u64 off,u32 bytes){
 if(bytes<sizeof(Record))return GN_CORRUPT;Record*h=PTR(Record,off);
 u64 floor=sizeof(Record)+(u64)h->n*sizeof(Term);
 if(h->magic!=MAGIC||h->bytes!=bytes||!h->n||h->degree<1||h->degree>S.target||floor>bytes)return GN_CORRUPT;
 if(h->checksum!=checksum(off+sizeof(Record),bytes-sizeof(Record)))return GN_CORRUPT;
 Term*t=PTR(Term,off+sizeof(Record));Word prev={0};
 for(u32 i=0;i<h->n;i++){
  Word w=t[i].w;
  if(h->degree>GN_INLINE_DEGREE){
   if(!wlong(w)||w.hi!=(WORD_LONG|h->degree)||w.lo<floor||w.lo>bytes||h->degree>bytes-w.lo)return GN_CORRUPT;
   w.lo+=off;
  }else if(wlong(w)||!weq(maskw(w,h->degree),w))return GN_CORRUPT;
  if(i&&wcmp(prev,w)<=0)return GN_CORRUPT;prev=w;
  for(u32 j=0;j<h->degree;j++)if(letter(w,h->degree,j)>=S.generators)return GN_CORRUPT;
  Coef c=t[i].c;if(c&1){u64 b=c_bigoff(c);if(b<floor||b>bytes-8)return GN_CORRUPT;u32 n=*PTR(u32,off+b);if(!n||8+(u64)n*4>bytes-b)return GN_CORRUPT;}else if(!c)return GN_CORRUPT;
 }return 0;
}
/* Variable-size immutable reducer cache. A generation-tagged ring uses the
 * byte budget for actual records, not sixteen equally oversized fixed slots.
 * No borrowed record pointer survives the next load_rule on the same lane. */
/* Rule I/O has its own budgeted lease. Resize only with readers joined; retained
 * exact rows own their coefficients and never borrow this transient buffer.
 * Helpers retain small buffers and defer records they cannot read. */
static int ensure_rule_io(Lane*l,u64 minimum){
 if(minimum<=l->io_size)return 0;
 if(minimum>UINT32_MAX)return GN_LIMIT;
 if(l->no_reserve||GN_LOAD(&S.batch_running))return GN_SCRATCH;
 u64 bytes=minimum,base=workspace_take(&bytes);if(!base)return GN_MEMORY;
 if(l->io_extra_base)workspace_return(l->io_extra_base,l->io_extra_bytes);
 l->io_extra_base=base;l->io_extra_bytes=bytes;l->io_base=base;l->io_size=bytes;
 return 0;
}
static Poly load_rule(u32 id,Lane*l){
 Rule*r=rule(id);u64 off=r->location;
 if(T.base&&!S.certifying&&id<=T.floor&&l->tail_snapshot>=r->tail_snapshot){
  if(r->tail_cache&&r->tail_generation<=l->tail_generation){
   Record*h=PTR(Record,r->tail_cache);GN_FETCH_ADD(&T.hits,1);
   return(Poly){r->tail_cache+sizeof(Record),h->n,h->degree,r->tail_cache};
  }
  if(!T.building&&!r->tail_cache&&!r->tail_tried&&r->degree<=S.completed&&r->n>1){
   GN_FETCH_ADD(&T.misses,1);GN_STORE(&T.requests[id&(TAIL_REQUESTS-1)],id);GN_FETCH_ADD(&T.queued,1);
  }
 }
 if(r->pinned){l->pinned_hits++;return(Poly){r->pinned+sizeof(Record),r->n,r->degree,r->pinned};}
 if(S.spill){
  Cache*c=PTR(Cache,l->cache_base)+(id&l->cache_mask);
  if(S.cache_percent&&c->id==id&&c->bytes==l->cache_epoch){off=c->offset;l->cache_hits++;}
  else{
   if(r->bytes>l->io_size){int rc=ensure_rule_io(l,r->bytes);if(rc){l->error=rc;return(Poly){0};}}
   int keep=S.cache_percent&&r->bytes<=l->cache_capacity;
   if(keep){
    if(r->bytes>l->cache_capacity-l->cache_used){
     l->cache_used=0;l->cache_epoch++;
     if(!l->cache_epoch){memset(PTR(u8,l->cache_base),0,((u64)l->cache_mask+1)*sizeof(Cache));l->cache_epoch=1;}
    }
    off=l->cache_data+l->cache_used;
   }else off=l->io_base;
   if(!gn_host_read(r->location,off,r->bytes)){l->error=GN_IO;return(Poly){0};}
   l->reads++;l->read_bytes+=r->bytes;
   if(validate_record(off,r->bytes)){l->error=GN_CORRUPT;return(Poly){0};}
   if(keep){c->id=id;c->bytes=l->cache_epoch;c->offset=off;l->cache_used+=A8(r->bytes);}
  }
 }
 return(Poly){off+sizeof(Record),r->n,r->degree,off};
}
static u32 exact_rule(Word w,u32 degree,u32 snapshot){u32 id=PTR(u32,S.lm_heads)[hash(w,degree)];while(id){Rule*r=rule(id);if(id<=snapshot&&r->degree==degree&&weq(r->lm,w))return id;id=r->next;}return 0;}
#include "matcher.inc"
static u32 divisor(Word w,u32 degree,u32 snapshot,u32*pos,Lane*l){
 if(l->delta_floor){
  /* Completed source row and newly appended same-degree tails are normal
   * against the immutable old snapshot. Only whole-word equality can act. */
  l->delta_queries++;*pos=0;u32 id=exact_rule(w,degree,snapshot);
  if(id>=l->delta_floor){l->delta_hits++;return id;}return 0;
 }
 /* Canonical export protects only its own leading word. Before enabling this,
  * canonical export checks that no other leading word divides it. All tails
  * are smaller, hence cannot contain that protected leading word. */
 if(l->skip_rule&&degree==rule(l->skip_rule)->degree&&weq(w,rule(l->skip_rule)->lm)){*pos=0;return 0;}
 RedCache*c=NULL;
 if(!wlong(w)){
  u32 index=(u32)mix(w.lo^w.hi),lane=(u32)(l-S.lanes);
  if(S.word_cache_base&&lane<S.word_cache_lanes)c=&PTR(RedCache,S.word_cache_base)[(u64)lane*S.word_cache_entries+(index&(S.word_cache_entries-1))];
  else c=&l->red[index&(RED_CACHE_N-1)];
  if(c->degree==degree&&weq(c->w,w)&&((c->id&&c->id<=snapshot)||c->version==snapshot+1)){
   *pos=c->pos;l->redcache_hits++;return c->id;
  }
 }
 u32 rid=0,rpos=0,first=1,maxlen=MIN(degree,snapshot?rule(snapshot)->degree:0);
 if(S.matcher_enabled&&S.matcher_nodes&&snapshot>=S.matcher_snapshot){
  l->matcher_queries++;rid=matcher_find(w,degree,&rpos,l);
  if(snapshot==S.matcher_snapshot)first=maxlen+1;
  else first=rule(S.matcher_snapshot+1)->degree;
  if(rid)maxlen=MIN(maxlen,rule(rid)->degree);
 }
 /* Newly appended rules are not in the immutable automaton. Search them using
  * the exact hash index; in a homogeneous degree epoch they have full degree.
  * A matcher built for a later snapshot is NEVER used for an earlier snapshot. */
 for(u32 len=first;len<=maxlen;len++){
  u32 stop=(rid&&rule(rid)->degree==len)?rpos:degree-len;
  for(u32 at=0;at<=stop;at++){
   l->hash_probes++;u32 id=exact_rule(part(w,degree,at,len),len,snapshot);
   if(id){rid=id;rpos=at;goto found;}
  }
 }
found:
 if(c)*c=(RedCache){w,snapshot+1,degree,rid,rpos};*pos=rpos;return rid;
}
static u32 prefix_count(Word w,u32 length,u32 full_degree,u32 snapshot){
 u32 node=PTR(u32,S.prefix_heads)[prefix_hash(w,length,full_degree)];
 while(node){Prefix*q=prefix(node);Rule*r=rule(q->rule);
  if(q->rule<=snapshot&&q->length==length&&r->degree==full_degree&&weq(part(r->lm,r->degree,0,length),w))return q->pad;
  node=q->next;
 }
 return 0;
}
static Poly copy_poly(Poly p,Arena*a,Word left,Word right,u32 nr,u32 degree){u64 off=alloc_a(a,(u64)p.n*sizeof(Term));if(!off)return(Poly){0};Term*t=PTR(Term,off);for(u32 i=0;i<p.n;i++){t[i].w=context(left,pw(p,i),p.degree,right,nr,degree,a);t[i].c=clonec(a,pc(p,i));}return(Poly){off,p.n,degree,0};}
/* Merge two sorted rows; multiplicative left-lex order preserves each input order. */
static Poly combine(Poly p,Coef sp,Poly g,Coef sg,Word left,Word right,u32 nr,Arena*a){
 u64 total=(u64)p.n+g.n;if(total>UINT32_MAX){a->error=GN_SCRATCH;return(Poly){0};}u64 off=alloc_a(a,total*sizeof(Term));if(!off)return(Poly){0};Term*out=PTR(Term,off),*pt=PTR(Term,p.off);u32 i=0,j=0,k=0;
 while(i<p.n||j<g.n){Word gw={0};if(j<g.n)gw=context(left,pw(g,j),g.degree,right,nr,p.degree,a);int cmp=i==p.n?-1:j==g.n?1:wcmp(pt[i].w,gw);Word w;Coef c;
  if(cmp>0){w=clonew(a,pw(p,i),p.degree);c=mulf(a,sp,pc(p,i++));}
  else if(cmp<0){w=gw;c=mulf(a,sg,pc(g,j++));}
  else{w=gw;c=addf(a,mulf(a,sp,pc(p,i++)),mulf(a,sg,pc(g,j++)));}
  if(a->error)return(Poly){0};if(c)out[k++]=(Term){w,c};
 }
 Poly r={off,k,p.degree,0};normalise(&r,a);return r;
}
/* These sufficient zero tests use only proved quadratic relations in the
 * current field: x_i^2=0 and x_i*x_j=q*x_j*x_i with q != 0. They do NOT
 * assume that all generators commute or that a matrix representation is
 * faithful. Skipping a term here is exact ideal membership, not a heuristic. */
/* Packed words of degree <=16 occupy the low 64 bits. Keep the proved
 * quadratic tests and their left-to-right order, with scalar nibble scans. */
static int eager_zero_short(u64 word,u32 degree,Lane*l){
 if(S.square_mask==((1u<<S.generators)-1)){
  u64 mask=(UINT64_C(1)<<(4*(degree-1)))-1;
  u64 x=(word^(word>>4))|~mask;
  if((x-UINT64_C(0x1111111111111111))&~x&UINT64_C(0x8888888888888888)){
   l->pruned++;l->insertion_prunes++;return 1;
  }
 }
 u64 scan=word<<(4*(16-degree));u32 pending=0;
 for(u32 j=0;j<degree;j++,scan<<=4){
  u32 c=(u32)(scan>>60),bit=1u<<c;
  if(pending&bit){l->pruned++;l->insertion_prunes++;l->commuting_prunes++;return 1;}
  pending=(pending&S.commute_mask[c])|(bit&S.square_mask);
 }
 return 0;
}
static int eager_zero(Word w,u32 degree,Lane*l){
 if(l->delta_floor||!S.pruning||!S.eager_pruning||!S.square_mask||degree<2)return 0;
 if(degree<=16&&!wlong(w))return eager_zero_short(w.lo,degree,l);
 if(!wlong(w)&&S.square_mask==((1u<<S.generators)-1)){
  Word q=shr(w,4),mask=maskw((Word){UINT64_MAX,UINT64_MAX},degree-1);
  u64 x=(w.lo^q.lo)|~mask.lo;
  int zero=!!((x-UINT64_C(0x1111111111111111))&~x&UINT64_C(0x8888888888888888));
  if(!zero&&degree>17){x=(w.hi^q.hi)|~mask.hi;zero=!!((x-UINT64_C(0x1111111111111111))&~x&UINT64_C(0x8888888888888888));}
  if(zero){l->pruned++;l->insertion_prunes++;return 1;}
 }
 u32 pending=0;
 for(u32 j=0;j<degree;j++){
  u32 c=letter(w,degree,j),bit=1u<<c;
  if(pending&bit){l->pruned++;l->insertion_prunes++;l->commuting_prunes++;return 1;}
  pending=(pending&S.commute_mask[c])|(bit&S.square_mask);
 }
 return 0;
}
/* Apply only oriented, actually known monic quadratic binomials, before
 * entering the sparse heap. Each swap strictly decreases degleftlex. A local
 * coefficient overflow simply stops preconditioning; the exact reducer still
 * receives an equivalent row and may use arbitrary precision afterwards. */
static void quadratic_precondition_short(Word*w,u32 degree,i64*c,Lane*l){
 u64 word=w->lo;u32 at=0;
 while(at+1<degree){
  u32 shift=4*(degree-at-2),pair=(u32)(word>>shift)&255;
  i64 q=S.swap_factor[pair];if(!q){at++;continue;}
  i64 next;
  if(S.modulus){i64 v=(*c)%(i64)S.modulus;if(v<0)v+=S.modulus;next=(i64)((u64)v*(u64)q%S.modulus);}
  else{u64 x=*c<0?(u64)(-*c):(u64)*c,y=q<0?(u64)(-q):(u64)q;
   if(y&&x>(u64)SMALL_MAX/y)return;next=(*c)*q;
  }
  u64 difference=(u64)((pair>>4)^(pair&15));
  word^=(difference|(difference<<4))<<shift;
  w->lo=word;*c=next;l->quadratic_swaps++;if(at)at--;
 }
}
static void quadratic_precondition(Word*w,u32 degree,i64*c,Lane*l){
 if(l->delta_floor||!S.quadratic_rewrite||degree<2||wlong(*w))return;
 if(degree<=16){quadratic_precondition_short(w,degree,c,l);return;}
 u32 at=0;
 while(at+1<degree){
  u32 a=letter(*w,degree,at),b=letter(*w,degree,at+1);i64 q=S.swap_factor[(a<<4)|b];
  if(!q){at++;continue;}
  i64 next;
  if(S.modulus){i64 v=(*c)%(i64)S.modulus;if(v<0)v+=S.modulus;next=(i64)((u64)v*(u64)q%S.modulus);}
  else{u64 x=*c<0?(u64)(-*c):(u64)*c,y=q<0?(u64)(-q):(u64)q;
   if(y&&x>(u64)SMALL_MAX/y)return;next=(*c)*q;
  }
  Word mask=shl((Word){a^b,0},4*(degree-at-1)),other=shl((Word){a^b,0},4*(degree-at-2));
  w->lo^=mask.lo^other.lo;w->hi^=mask.hi^other.hi;*c=next;l->quadratic_swaps++;
  if(at)at--;
 }
}
#include "local_rewrites.inc"
#include "radix_queue.inc"
#include "heap_nf.inc"
#include "rational_heap_nf.inc"
#include "big_rational_nf.inc"
/* Budgeted overflow workspaces leased by exceptional rows. No spinning:
 * a busy reserve defers the task to the ordered commit barrier. Successful results
 * are wholly owned by the original output arena before releasing the lease. */
static int reserve_nf(Lane*l,Poly p,u32 active,u32 snapshot){
 if(l->no_reserve)return GN_DEFERRED;
 if(!l->reserve_retry){
  if(!(l->is_commit&&S.commit_reserve_base?S.commit_reserve_base:S.reserve_base))return HEAP_MISS;
  if(!l->reserve_slot&&!reserve_acquire(l)){
   l->reserve_busy++;l->reserve_waiting=1;
   if(l->slice_enabled){l->reserve_direct=1;l->resume_tier=5;l->memory_wait=ROW_WAIT_RESERVE;return GN_ROW_WAIT;}
   return GN_DEFERRED;
  }
  l->reserve_attempts++;l->reserve_saved=l->a[active^1];l->reserve_retry=1;
  u64 base=reserve_lease_base(l),bytes=reserve_lease_bytes(l);l->a[active^1]=(Arena){base,base,base+bytes,0,0};
  l->rational_maxed=0;
 }
 int rc=HEAP_MISS,attempted_big=0;
 if(l->resume_tier==4){attempted_big=1;l->reduction_tier=6;rc=big_rational_nf(l,p,active,snapshot);}
 else if(S.rational_enabled&&!l->reserve_direct){l->reduction_tier=5;u64 steps=l->reductions;rc=rational_nf(l,p,active,snapshot);l->rational_steps+=l->reductions-steps;}
 /* A resumed big-rational row already used this reserve. Retrying it from the
  * original polynomial at the same capacity loses its exact partial state;
  * if that retry yields, every later capacity miss repeats the same search.
  * Propagate exhaustion to the caller's memory adaptation instead. A compact
  * rational miss may still promote to big-rational arithmetic once. */
 if(rc<0&&S.big_rational_enabled&&!attempted_big){l->resume_tier=0;l->reduction_tier=6;rc=big_rational_nf(l,p,active,snapshot);}
 
 if(rc==GN_YIELD||rc==GN_ROW_WAIT)return rc;
 l->resume_tier=0;l->reserve_peak=MAX(l->reserve_peak,l->a[active^1].peak);
 l->a[active^1]=l->reserve_saved;l->reserve_retry=0;
 if(!rc)l->reserve_successes++;else if(rc<0)l->reserve_misses++;
 reserve_release(l);return rc;
}
typedef struct {Poly p;u32 active,scan,tried;u64 steps;} NResume;
static NResume nresume[GN_RESUME_SLOTS];
static int nf(Lane*l,u32 snapshot){
 if(l->memory_wait)return GN_ROW_WAIT;
 l->tail_snapshot=snapshot;if(!l->resume_tier)l->tail_generation=T.generation;
 u32 active=l->active;Poly p=l->result;u64 steps=0;u32 scan=0,heap_tried=0;
 u64 capacity_mark=l->big_capacity_misses+l->big_pool_misses+l->big_arena_misses;
 if(l->resume_tier){heap_tried=1;l->slice_resumes++;
  if(l->reserve_retry||l->resume_tier==5)goto resume_reserve;
  if(l->resume_tier==1)goto resume_integer;
  if(l->resume_tier==2)goto resume_rational;
  if(l->resume_tier==4)goto resume_big;
  if(l->resume_tier==3){NResume*sv=&nresume[l->resume_slot];p=sv->p;active=sv->active;scan=sv->scan;steps=sv->steps;heap_tried=sv->tried;l->resume_tier=0;goto general;}
 }
 l->rational_maxed=0;l->reduction_tier=3;
 if(S.heap_enabled&&p.degree<=GN_INLINE_DEGREE&&p.n>=S.heap_threshold){
start_optimized:
  heap_tried=1;l->heap_attempts++;
resume_integer:;
  u64 prior_steps=l->reductions;l->reduction_tier=1;int hr=heap_nf(l,p,active,snapshot);
  l->integer_steps+=l->reductions-prior_steps;if(hr==GN_YIELD)return hr;l->resume_tier=0;
  if(hr>=0){if(!hr)l->heap_successes++;return hr;}l->heap_fallbacks++;
  if(S.rational_enabled&&!S.modulus){l->rational_attempts++;
resume_rational:;
   u64 prev=l->reductions;l->reduction_tier=2;int rr=rational_nf(l,p,active,snapshot);l->rational_steps+=l->reductions-prev;
   if(rr==GN_YIELD)return rr;
   if(rr==GN_DEFERRED&&l->slice_enabled&&!l->no_reserve){l->reserve_direct=1;l->resume_tier=5;l->memory_wait=ROW_WAIT_RESERVE;return GN_ROW_WAIT;}
   l->resume_tier=0;if(rr>=0){if(!rr)l->rational_successes++;return rr;}l->rational_fallbacks++;
  }
  if(S.big_rational_enabled&&!S.modulus){l->big_attempts++;
resume_big:;
   l->reduction_tier=4;int br=big_rational_nf(l,p,active,snapshot);
   if(br==GN_YIELD||br==GN_ROW_WAIT)return br;l->resume_tier=0;if(br>=0){if(!br)l->big_successes++;return br;}l->big_fallbacks++;
  }
  if(!S.modulus&&(l->rational_maxed||S.big_rational_enabled)){
resume_reserve:;
   int rr=reserve_nf(l,p,active,snapshot);if(rr==GN_YIELD||rr==GN_ROW_WAIT)return rr;l->resume_tier=0;if(rr>=0)return rr;
  }
  /* Inline exact rows must never restart in the whole-row-copy reducer after
   * sparse exhaustion. Cooperative state is parked; other callers get a limit. */
  if(S.big_rational_enabled)return GN_SCRATCH;
  if(S.auto_memory&&l->allow_repack&&S.workers>1&&(l->rational_maxed||l->big_capacity_misses+l->big_pool_misses+l->big_arena_misses>capacity_mark))return GN_REPACK;
 }
 if(heap_tried)l->general_fallbacks++;
 l->reduction_tier=3;
general:
 for(;;){
 if(p.n>=4096&&p.degree>GN_INLINE_DEGREE)return GN_LIMIT;
 if(!heap_tried&&S.heap_enabled&&p.degree<=GN_INLINE_DEGREE&&p.n>=S.heap_threshold){l->result=p;l->active=active;goto start_optimized;}
if(l->a[active].error)return l->a[active].error;if((steps&255)==0){publish_lane(l,p.n,0);if(cancelled())return GN_CANCELLED;
  if(slice_expired(l)){NResume*sv=&nresume[l->resume_slot];*sv=(NResume){p,active,scan,heap_tried,steps};l->resume_tier=3;l->slice_yields++;return GN_YIELD;}}
Term*t=PTR(Term,p.off);u32 idx=scan,pos=0,id=0;
  for(;idx<p.n;idx++){id=divisor(t[idx].w,p.degree,snapshot,&pos,l);if(id)break;}
  if(!id){int rc=normalise(&p,&l->a[active]);l->result=p;l->active=active;return rc;}
  l->reductions++;steps++;scan=idx;Rule*rr=rule(id);
  if(S.pruning&&rr->n==1){memmove(t+idx,t+idx+1,(size_t)(p.n-idx-1)*sizeof(Term));p.n--;l->pruned++;continue;}
  Poly g=load_rule(id,l);if(l->error)return l->error;Arena*a=&l->a[active^1];reset_a(a);Coef c=pc(p,idx),lc=pc(g,0),sp,sg;
  if(lc==2){sp=2;sg=negf(c);}
  else if(S.modulus){sp=2;sg=negf(csmall((i64)((u64)cvalue(c)*fpow((u32)cvalue(lc),S.modulus-2)%S.modulus)));}
  else{Coef z=gcdc(a,c,lc);sp=exactdiv(a,lc,z);sg=cneg(exactdiv(a,c,z));}
  if(a->error)return a->error;Word w=t[idx].w;u32 nr=p.degree-pos-g.degree;Word left=part(w,p.degree,0,pos),right=part(w,p.degree,pos+g.degree,nr);
  Poly q=combine(p,sp,g,sg,left,right,nr,a);if(a->error)return a->error;p=q;active^=1;
 }
}
static int reserve_slots(u32 nmore){if(S.nrules==UINT32_MAX||nmore>UINT32_MAX-S.nprefix)return GN_LIMIT;u32 rpage=S.nrules/PAGE_N,pfirst=S.nprefix/PAGE_N,plast=(S.nprefix+nmore-1)/PAGE_N;
 if(rpage>=S.table_capacity||(nmore&&plast>=S.table_capacity))return GN_MEMORY;
 u64*rp=PTR(u64,S.rule_pages),*pp=PTR(u64,S.prefix_pages);if(!rp[rpage]){u64 o=alloc_p(PAGE_N*sizeof(Rule));if(!o)return S.error;rp[rpage]=o;}
 if(nmore)for(u32 i=pfirst;i<=plast;i++)if(!pp[i]){u64 o=alloc_p(PAGE_N*sizeof(Prefix));if(!o)return S.error;pp[i]=o;}return 0;
}
static u32 fg_step(u32 parity,u32 group,u32 generator);
static u64 fg_lower_group(u32 degree,u32 group);
static int fg_poly_homogeneous(Poly p);
static int fg_append_check(Poly p,int restoring);
static int fg_append_done(Poly p,int restoring);
static int fg_sector_ids(u32 f,u32 g,u32 k);
static u32 fg_pair_group(u32 f,u32 g,u32 k);
static void fg_note_pair_commit(u32 f,u32 g,u32 k,u32 rules_before);
static int fg_sector_pair(Lane*l);
#include "delta_commit.inc"
static int append_rule(Poly p,u64 existing_disk,int restoring){
 if(!p.n){S.commit_zero++;return 0;}Word leading=pw(p,0);if(S.nrules&&p.degree<rule(S.nrules)->degree)return GN_STATE;
 if(exact_rule(leading,p.degree,S.nrules))return GN_STATE;
 int gate_rc=fg_append_check(p,restoring);if(gate_rc)return gate_rc;
 int rc=reserve_slots(p.degree-1);if(rc)return rc;u64 size=record_bytes(p),location=0;Lane*l=&S.lanes[0];
 if(S.spill){location=restoring?existing_disk:S.disk_end;if(!restoring){rc=ensure_rule_io(l,size);if(rc)return rc;rc=write_record(p,l->io_base,l->io_size);if(rc)return rc;if(!gn_host_write(location,l->io_base,(u32)size))return GN_IO;}S.disk_end=MAX(S.disk_end,location+size);}
 else{location=alloc_p(size);if(!location)return S.error;rc=write_record(p,location,size);if(rc)return rc;}
 if(wlong(leading)){u64 owned=alloc_p(p.degree);if(!owned)return S.error;memcpy(PTR(u8,owned),PTR(u8,leading.lo),p.degree);leading.lo=owned;}
 u32 id=++S.nrules,b=hash(leading,p.degree);Rule*r=rule(id);*r=(Rule){leading,location,(u32)size,p.n,p.degree,PTR(u32,S.lm_heads)[b],0,0,0,0,0};PTR(u32,S.lm_heads)[b]=id;
 for(u32 len=1;len<p.degree;len++){
  Word key=part(r->lm,p.degree,0,len);u32 h=prefix_hash(key,len,p.degree);
  u32 count=prefix_count(key,len,p.degree,id-1)+1,pid=++S.nprefix;
  Prefix*q=prefix(pid);*q=(Prefix){id,PTR(u32,S.prefix_heads)[h],len,count};PTR(u32,S.prefix_heads)[h]=pid;
 }
 if(p.degree==2){
  u32 a=letter(leading,2,0),b=letter(leading,2,1);
  if(p.n==1&&a==b)S.square_mask|=1u<<a;
  if(p.n==2&&a!=b){Word tail=pw(p,1);
   if(letter(tail,2,0)==b&&letter(tail,2,1)==a){
    S.commute_mask[a]|=1u<<b;S.commute_mask[b]|=1u<<a;
    Coef lc=pc(p,0),tc=pc(p,1);
    if(a>b&&lc==2&&!(tc&1))S.swap_factor[(a<<4)|b]=S.modulus?(i64)S.modulus-cvalue(tc):-cvalue(tc);
   }
  }
 }
 if(S.spill && size<=S.pin_capacity-S.pin_used){
  u64 dest=S.pin_base+S.pin_used;
  if(restoring)memcpy(PTR(u8,dest),PTR(u8,l->io_base),size);
  else{int prc=write_record(p,dest,size);if(prc)return prc;}
  r->pinned=dest;S.pin_used+=A8(size);
 }
 S.largest_rule_bytes=MAX(S.largest_rule_bytes,size);S.terms+=p.n;return fg_append_done(p,restoring);
}
API u32 gn_abi(void){return GN_ABI;}
API u64 gn_heap_base(void){
#ifdef __wasm__
 return A8((u64)(uintptr_t)&__heap_base);
#else
 return 65536;
#endif
}
static Lane coop_coordinator;
static Lane coop_helpers[GN_MAX_WORKERS];
static void layout_one(Lane*l,u64 begin,u64 bytes){
 u64 cache_bytes=MAX(UINT64_C(2048),(bytes*S.cache_percent/100)&~UINT64_C(7));
 u64 work=((bytes-bytes/8-(S.batch_enabled?bytes/8:0)-cache_bytes)/2)&~UINT64_C(7);
 l->a[0]=(Arena){begin,begin,begin+work,0,0};begin+=work;
 l->a[1]=(Arena){begin,begin,begin+work,0,0};begin+=work;
 l->io_base=begin;l->io_size=(bytes/8)&~UINT64_C(7);begin+=l->io_size;
 l->cache_base=begin;u32 slots=64;while(slots<65536&&(u64)slots*2*512<=cache_bytes)slots*=2;
 l->cache_mask=slots-1;l->cache_epoch=1;l->cache_used=0;
 memset(PTR(u8,begin),0,(size_t)slots*sizeof(Cache));
 l->cache_data=begin+(u64)slots*sizeof(Cache);l->cache_capacity=cache_bytes-(u64)slots*sizeof(Cache);begin+=cache_bytes;
 l->out_base=begin;l->out_size=S.batch_enabled?l->a[0].base+bytes-begin:0;
}
static int layout_workers(u32 workers,int preserve){
 if(!workers||workers>GN_MAX_WORKERS)return GN_INPUT;if(GN_LOAD(&S.batch_running))return GN_STATE;
 u64 bytes=(S.scratch_size/(workers+(S.coop_ms?1:0)))&~UINT64_C(65535);
 if(bytes<1024*1024)return GN_MEMORY;S.workers=workers;S.lane_slots=MAX(S.lane_slots,workers);
 for(u32 i=0;i<S.lane_slots;i++)if(S.lanes[i].io_extra_base){workspace_return(S.lanes[i].io_extra_base,S.lanes[i].io_extra_bytes);S.lanes[i].io_extra_base=S.lanes[i].io_extra_bytes=0;}
 for(u32 i=0;i<workers;i++){
  Lane*l=&S.lanes[i];if(!preserve){memset(l,0,sizeof(*l));memset(&S.live[i],0,sizeof(LiveLane));}
  else{l->result=(Poly){0};l->error=0;l->active=0;l->out_used=0;l->skip_rule=0;l->busy=0;l->allow_repack=0;l->reserve_owned=0;memset(l->red,0,sizeof(l->red));}
  l->resume_tier=0;l->slice_enabled=0;l->reserve_retry=0;l->resume_slot=i;
  layout_one(l,S.scratch_base+bytes*i,bytes);
 }
 if(S.coop_ms){
  if(coop_coordinator.io_extra_base)workspace_return(coop_coordinator.io_extra_base,coop_coordinator.io_extra_bytes);
  memset(&coop_coordinator,0,sizeof(coop_coordinator));coop_coordinator.resume_slot=GN_MAX_WORKERS;coop_coordinator.is_commit=1;layout_one(&coop_coordinator,S.scratch_base+bytes*workers,bytes);
  /* Optional helper arenas use at most 1/64 of the configured total budget.
   * Primary scratch and the exceptional reserve keep their original sizes.
   * Admission is optional: retain room for persistent rules and never fail
   * the calculation merely because helpers cannot fit. */
  if(!S.helper_base){
   u64 wanted=S.budget/64,each=(wanted/workers)&~UINT64_C(65535),total=each*workers;
   if(each>=1048576&&S.bump<=S.budget&&total<=(S.budget-S.bump)/4&&gn_host_ensure(S.bump+total)){
    S.helper_base=S.bump;S.helper_bytes=total;S.bump+=total;S.allocated_peak=MAX(S.allocated_peak,S.bump);
   }
  }
  for(u32 i=0;i<GN_MAX_WORKERS;i++)memset(&coop_helpers[i],0,sizeof(Lane));
  u64 each=(S.helper_bytes/workers)&~UINT64_C(65535);
  if(S.helper_base&&each>=1048576)for(u32 i=0;i<workers;i++){
   Lane*h=&coop_helpers[i];h->resume_slot=GN_MAX_WORKERS+1+i;h->no_reserve=1;layout_one(h,S.helper_base+each*i,each);
  }
 }
 return 0;
}
API int gn_workers(u32 workers){return layout_workers(workers,0);}
API int gn_batch_mode(u32 enabled){S.batch_enabled=!!enabled;return gn_workers(S.workers);}
API int gn_init(u32 generators,u32 degree,u32 workers,u64 budget,u64 scratch_pool,u32 hash_bits,u32 modulus,u32 spill){
 if(!generators||generators>16||degree>GN_INDEX_MAX||budget>GN_HARD_BYTES||scratch_pool>budget||scratch_pool<1024*1024||hash_bits<8||hash_bits>26||modulus==1||modulus>2147483647u)return GN_INPUT;
 if(modulus){for(u32 d=2;(u64)d*d<=modulus;d++)if(modulus%d==0)return GN_INPUT;}
 /* A fresh allocator cannot accept a lease from the preceding calculation.
  * This matters when a Wasm instance is reused, or another checkpoint is tried. */
 coop_coordinator.io_extra_base=coop_coordinator.io_extra_bytes=0;
 gn_lb_release();memset(&P,0,sizeof(P));memset(&T,0,sizeof(T));memset(&S,0,sizeof(S));S.abi=GN_ABI;S.generators=generators;S.target=degree?degree:GN_INDEX_MAX;S.pruning=1;S.heap_enabled=1;S.rational_enabled=1;S.rational_rewrites=1;S.big_rational_enabled=1;S.growing_rational=1;S.reserve_growth=1;S.radix_enabled=1;S.radix_cache_enabled=1;S.matcher_enabled=1;S.chain_enabled=1;S.telemetry_enabled=1;S.eager_pruning=1;S.quadratic_rewrite=1;S.cost_scheduling=1;S.matcher_limit=MIN(budget/16,UINT64_C(67108864));S.cache_percent=12;S.heap_threshold=16;S.budget=budget;S.modulus=modulus;S.spill=!!spill;S.base=gn_heap_base();S.bump=S.base;S.stack_base=alloc_p((u64)GN_MAX_WORKERS*STACK_BYTES);if(!S.stack_base)return S.error;
 S.scratch_base=alloc_p(scratch_pool);if(!S.scratch_base)return S.error;S.scratch_size=scratch_pool;int rc=gn_workers(workers);if(rc)return rc;
 S.hash_mask=((u32)1<<hash_bits)-1;u64 hb=((u64)S.hash_mask+1)*4;S.lm_heads=alloc_p(hb);S.prefix_heads=alloc_p(hb);if(S.error)return S.error;memset(PTR(u8,S.lm_heads),0,(size_t)hb);memset(PTR(u8,S.prefix_heads),0,(size_t)hb);
 S.table_capacity=(u32)MIN((budget/(PAGE_N*sizeof(Prefix))+2),(u64)UINT32_MAX/PAGE_N+1);u64 tb=(u64)S.table_capacity*8;S.rule_pages=alloc_p(tb);S.prefix_pages=alloc_p(tb);if(S.error)return S.error;memset(PTR(u8,S.rule_pages),0,(size_t)tb);memset(PTR(u8,S.prefix_pages),0,(size_t)tb);return 0;
}
API int gn_tune(u32 flags,u32 cache_percent,u32 heap_threshold){
 if(S.current||S.input_expected||cache_percent>40||heap_threshold<1||heap_threshold>1048576u||flags>3)return GN_INPUT;
 S.pruning=!!(flags&1);S.heap_enabled=!!(flags&2);S.cache_percent=cache_percent;S.heap_threshold=heap_threshold;return gn_workers(S.workers);
}
API int gn_rational_heap(u32 enabled){if(S.current||S.input_expected||enabled>1)return GN_INPUT;S.rational_enabled=enabled;return 0;}
API int gn_optimize(u32 flags,u64 matcher_budget){
 if(S.current||S.input_expected||flags>63||matcher_budget>S.budget)return GN_INPUT;
 S.matcher_enabled=!!(flags&1);S.chain_enabled=!!(flags&2);S.telemetry_enabled=!!(flags&4);
 S.matcher_limit=matcher_budget;S.eager_pruning=!!(flags&8);S.quadratic_rewrite=!!(flags&16);S.cost_scheduling=!!(flags&32);return 0;
}
/* Optional per-lane word->divisor cache. Exact word comparison plus snapshot
 * validity checks are unchanged. It holds no polynomial normal forms. At most
 * budget/16 extra bytes; denied optional growth falls back to a smaller table. */
API int gn_gm_config(u32 mask){if(mask>7)return GN_INPUT;if(S.current||S.input_expected)return GN_STATE;S.gm_mask=S.gm_requested=mask;return 0;}
API u64 gn_gm_stat(u32 key){switch(key){case 0:return S.gm_mask;case 1:return GN_LOAD(&S.gm_examined);case 2:return GN_LOAD(&S.gm_skipped[0]);case 3:return GN_LOAD(&S.gm_skipped[1]);case 4:return GN_LOAD(&S.gm_skipped[2]);case 5:return GN_LOAD(&S.gm_unavailable);case 6:return GN_LOAD(&S.gm_pending);case 7:return GN_LOAD(&S.chain_fallback_queries);default:return 0;}}
API int gn_tail_cache_prepare(void){return tail_cache_prepare();}
API int gn_word_cache(u32 entries){
 if(S.current||S.input_expected||S.nrules||entries>1048576u)return GN_INPUT;
 if(!entries)entries=RED_CACHE_N;
 if(entries<RED_CACHE_N||(entries&(entries-1)))return GN_INPUT;
 if(S.word_cache_base)return GN_STATE; /* configure once after each gn_init */
 while(entries>RED_CACHE_N){
  u64 bytes=(u64)entries*S.workers*sizeof(RedCache);
  if(bytes<=S.budget/16&&bytes<=S.budget-S.bump&&gn_host_ensure(S.bump+bytes)){
   S.word_cache_base=S.bump;S.word_cache_bytes=bytes;S.word_cache_entries=entries;S.word_cache_lanes=S.workers;
   S.bump+=bytes;S.allocated_peak=MAX(S.allocated_peak,S.bump);memset(PTR(u8,S.word_cache_base),0,(size_t)bytes);return 0;
  }
  entries/=2;
 }
 S.word_cache_entries=RED_CACHE_N;return 0;
}
API u64 gn_live_stat(u32 lane,u32 key){
 if(lane>=S.lane_slots)return 0;LiveLane*v=&S.live[lane];
 switch(key){case 0:return GN_LOAD(&v->reductions);case 1:return GN_LOAD(&v->pruned);
 case 2:return GN_LOAD(&v->reads);case 3:return GN_LOAD(&v->pairs);case 4:return GN_LOAD(&v->terms);
 case 5:return GN_LOAD(&v->hash_probes);case 6:return GN_LOAD(&v->matcher_queries);
 case 7:return GN_LOAD(&v->busy);case 8:return GN_LOAD(&v->sequence);case 9:return GN_LOAD(&v->tier);case 10:return GN_LOAD(&v->exact_fallbacks);
 case 11:return GN_LOAD(&v->left_rule);case 12:return GN_LOAD(&v->right_rule);case 13:return GN_LOAD(&v->overlap);
 case 14:return GN_LOAD(&v->big_capacity);case 15:return GN_LOAD(&v->big_reserved);case 16:return GN_LOAD(&v->big_peak_terms);
 case 17:return GN_LOAD(&v->big_coefficient_live);case 18:return GN_LOAD(&v->big_coefficient_bytes);case 19:return GN_LOAD(&v->big_growths);
 case 20:return GN_LOAD(&v->big_capacity_misses);case 21:return GN_LOAD(&v->big_pool_misses);case 22:return GN_LOAD(&v->big_arena_misses);
 case 23:return GN_LOAD(&v->big_fallbacks);case 24:return GN_LOAD(&v->big_reserve_waits);case 25:return GN_LOAD(&v->big_pool_high_water);case 26:return GN_LOAD(&v->big_arithmetic_high_water);case 27:return GN_LOAD(&v->big_collected_live_high_water);case 28:return GN_LOAD(&v->memory_wait);case 29:return GN_LOAD(&v->memory_need);case 30:return GN_LOAD(&v->row_growths);case 31:return GN_LOAD(&v->memory_detail);case 32:return GN_LOAD(&v->row_workspace_bytes);case 33:return GN_LOAD(&v->memory_live_bytes);case 34:return GN_LOAD(&v->memory_minimum_bytes);case 35:return GN_LOAD(&v->row_relayouts);default:return 0;}
}
API u64 gn_progress_stat(u32 key){
 switch(key){case 0:return S.degree_total;case 1:return S.degree_seen;
 case 2:return S.degree_committed;case 3:return S.degree_scheduled;
 case 4:return S.degree_monomial;case 5:return S.degree_chain;
 case 6:return S.degree_replays;case 7:return S.degree_total_known;default:return 0;}
}
API void gn_deadline(double absolute_ms){S.deadline=absolute_ms;}
API u64 gn_completion_bound(void){return S.nrules?(u64)rule(S.nrules)->degree*2-1:0;}
API u64 gn_stack_top(u32 lane){return lane<GN_MAX_WORKERS?S.stack_base+(u64)(lane+1)*STACK_BYTES:0;}
API u64 gn_cancel_ptr(void){
#ifdef __wasm__
 return(u64)(uintptr_t)&S.cancel;
#else
 return 0;
#endif
}
API void gn_cancel(u32 value){GN_STORE(&S.cancel,value);}
API u64 gn_stat(u32 key){switch(key){case 0:return S.nrules;case 1:return S.terms;case 2:return S.completed;case 3:return S.current;case 4:return S.bump;case 5:return S.budget;case 6:return S.disk_end;case 7:return S.pair_count;case 8:return S.zero_pairs;case 9:return S.commit_zero;case 10:return S.workers;case 11:return S.nprefix;case 12:return S.allocated_peak;case 13:return S.error;case 14:return S.target;case 15:return S.generators;case 16:return S.modulus;case 17:return S.batch_epochs;case 18:return S.batch_spills;case 19:return S.hilbert_nodes;case 20:return S.hilbert_bytes;case 21:return S.pruning;case 22:return S.heap_enabled;case 23:return S.cache_percent;case 24:return S.heap_threshold;case 25:return S.matcher_nodes;
 case 26:return S.matcher_allocated;case 27:return S.matcher_builds;case 28:return S.matcher_fallbacks;
 case 29:return S.chain_skipped;case 30:return S.matcher_enabled;case 31:return S.chain_enabled;
 case 32:return S.telemetry_enabled;case 33:return S.matcher_snapshot;case 34:return S.eager_pruning;case 35:return S.quadratic_rewrite;case 36:return S.cost_scheduling;case 37:return S.word_cache_entries?S.word_cache_entries:RED_CACHE_N;case 38:return S.word_cache_bytes;case 39:return S.pin_capacity;case 40:return S.pin_used;case 41:return S.local_degree;case 42:return S.local_used;case 43:return S.local_capacity;case 44:return S.local_entries;case 45:return S.local_declined;case 46:return S.local_built;case 47:return S.local_snapshot;case 48:return S.rational_rewrites;default:return 0;}}
API u64 gn_lane_stat(u32 lane,u32 key){if(lane>=S.lane_slots)return 0;Lane*l=&S.lanes[lane];switch(key){case 27:return l->pinned_hits;case 26:return l->local_hits;case 24:return l->integer_steps;case 25:return l->rational_steps;case 21:return l->rational_attempts;case 22:return l->rational_successes;case 23:return l->rational_fallbacks;case 0:return l->reductions;case 1:return l->pruned;case 2:return l->reads;case 3:return l->read_bytes;case 4:return MAX(l->a[0].peak,l->a[1].peak);case 5:return l->error;case 6:return l->pairs;case 7:return l->cache_hits;case 8:return l->hash_probes;
 case 9:return l->matcher_queries;case 10:return l->matcher_characters;case 11:return l->redcache_hits;
 case 12:return l->heap_attempts;case 13:return l->heap_successes;case 14:return l->heap_fallbacks;case 15:return l->insertion_prunes;case 16:return l->commuting_prunes;case 17:return l->quadratic_swaps;default:return 0;}}
API u32 gn_result_count(u32 lane){return lane<S.workers?S.lanes[lane].result.n:0;}
API int gn_input_begin(u32 degree,u32 terms){if(S.fg_external==1||S.current||(!S.certifying&&degree!=S.completed+1)||degree<1||degree>S.target||!terms||S.input_expected)return GN_STATE;Lane*l=&S.lanes[0];reset_a(&l->a[0]);reset_a(&l->a[1]);l->error=0;l->active=0;u64 off=alloc_a(&l->a[0],(u64)terms*sizeof(Term));if(!off)return GN_SCRATCH;l->result=(Poly){off,terms,degree,0};S.input_degree=degree;S.input_expected=terms;S.input_used=0;return 0;}
API int gn_input_term(u64 lo,u64 hi,i64 coefficient){if(!S.input_expected||S.input_used>=S.input_expected||coefficient>SMALL_MAX||coefficient< -SMALL_MAX||!coefficient)return GN_INPUT;Word w={lo,hi};if(S.input_degree>GN_INLINE_DEGREE)return GN_INPUT;if(!weq(maskw(w,S.input_degree),w))return GN_INPUT;for(u32 i=0;i<S.input_degree;i++)if(part(w,S.input_degree,i,1).lo>=S.generators)return GN_INPUT;Lane*l=&S.lanes[0];Coef c;if(S.modulus){i64 z=coefficient%(i64)S.modulus;if(z<0)z+=S.modulus;c=csmall(z);}else c=csmall(coefficient);PTR(Term,l->result.off)[S.input_used++]=(Term){w,c};return 0;}
API int gn_input_bytes(u32 length,i64 coefficient){
 if(!S.input_expected||S.input_used>=S.input_expected||length!=S.input_degree||length<=GN_INLINE_DEGREE||!coefficient||coefficient>SMALL_MAX||coefficient< -SMALL_MAX)return GN_INPUT;
 Lane*l=&S.lanes[0];if(length>l->io_size)return GN_SCRATCH;
 const u8*src=PTR(u8,l->io_base);for(u32 i=0;i<length;i++)if(src[i]>=S.generators)return GN_INPUT;
 u64 off=alloc_a(&l->a[0],length);if(!off)return l->a[0].error;memcpy(PTR(u8,off),src,length);
 i64 c=coefficient;if(S.modulus){c%=(i64)S.modulus;if(c<0)c+=S.modulus;}
 PTR(Term,l->result.off)[S.input_used++]=(Term){{off,WORD_LONG|length},csmall(c)};return 0;
}
API int gn_input_end(void){if(S.input_used!=S.input_expected||!S.input_expected)return GN_STATE;S.input_expected=0;Lane*l=&S.lanes[0];if(S.fg_external&&!fg_poly_homogeneous(l->result))return GN_INPUT;Term*t=PTR(Term,l->result.off);u32 n=l->result.n;/* Inputs are small; insertion sort avoids library allocation. */
 for(u32 i=1;i<n;i++){Term x=t[i];u32 j=i;while(j&&wcmp(t[j-1].w,x.w)<0){t[j]=t[j-1];--j;}t[j]=x;}
 u32 k=0;for(u32 i=0;i<n;i++){if(k&&weq(t[k-1].w,t[i].w)){t[k-1].c=addf(&l->a[0],t[k-1].c,t[i].c);if(!t[k-1].c)--k;}else if(t[i].c)t[k++]=t[i];}l->result.n=k;if(l->a[0].error)return l->a[0].error;int rc=normalise(&l->result,&l->a[0]);if(!rc)rc=nf(l,S.nrules);if(!rc)rc=S.certifying?(l->result.n?GN_REJECTED:0):append_rule(l->result,0,0);return rc;}
#include "tail_cache.inc"
#include "nc_gm.inc"
#include "pair_plan.inc"
static void reset_degree_progress(void){S.degree_seen=0;S.degree_scheduled=0;S.degree_committed=0;S.degree_monomial=0;S.degree_chain=0;}
API int gn_start_degree(u32 degree){
 if(cancelled())return GN_CANCELLED;if(S.current||degree!=S.completed+1||degree>S.target)return GN_STATE;
 S.gate_active=S.gate_closed=0;S.gate_skipped=0;S.gm_mask=S.gm_requested;S.current=degree;S.degree_snapshot=S.nrules;S.iter_f=1;S.iter_k=1;S.iter_node=0;S.iter_ready=0;S.iter_done=0;
 reset_degree_progress();S.degree_total=0;S.degree_total_known=0;S.degree_replays=0;
 int rc=matcher_build();if(rc)return rc;
 rc=local_build();if(rc)return rc;
 if(S.telemetry_enabled){
  /* Each prefix node stores the exact population of its word/length/full-degree
   * group. Summing those populations counts all candidates without an S-pair
   * traversal, polynomial reduction, future-degree search or materialized queue. */
  for(u32 id=1;id<=S.degree_snapshot;id++){
   if((id&1023)==0){(void)gn_host_clock();if(cancelled())return GN_CANCELLED;}
   Rule*f=rule(id);if(f->degree>=degree)continue;
   for(u32 k=1;k<f->degree;k++){
    u32 glen=degree-f->degree+k;if(glen<=k||glen>=degree)continue;
    u32 count=prefix_count(part(f->lm,f->degree,f->degree-k,k),k,glen,S.degree_snapshot);
    if(UINT64_MAX-S.degree_total<count)return GN_LIMIT;
    S.degree_total+=count;
   }
  }
  S.degree_total_known=1;
 }
 P.active=0;P.count=P.cursor=0;P.anchor_seen=P.anchor_n=0;P.excluded_bytes=0;P.excluded_count=0;
 if(P.requested&&degree>=P.min_degree){int planned=plan_build(P.requested,0,NULL,0);if(planned<0)return -planned;}
 return 0;
}
API int gn_rewind_degree(void){if(!S.current)return GN_STATE;if(P.active&&P.anchor_seen){P.excluded_bytes=0;P.excluded_count=0;int rc=plan_build(P.mode,0,NULL,0);if(rc<0)return -rc;if(!rc)P.active=0;}else if(P.active)P.cursor=0;reset_degree_progress();S.degree_replays++;S.iter_f=1;S.iter_k=1;S.iter_node=0;S.iter_ready=0;S.iter_done=0;return 0;}
API int gn_next_pair(u32 lane){if(lane>=S.workers||!S.current)return -GN_STATE;if(P.active)return S.iter_done?0:plan_next(lane);Lane*l=&S.lanes[lane];if(S.iter_done)return 0;u64 polls=0;
 while(S.iter_f<=S.degree_snapshot){if((++polls&1023)==0){if(S.telemetry_enabled)(void)gn_host_clock();if(cancelled())return -GN_CANCELLED;}Rule*f=rule(S.iter_f);if(f->degree>=S.current||S.iter_k>=f->degree){S.iter_f++;S.iter_k=1;S.iter_ready=0;continue;}
  u32 k=S.iter_k,glen=S.current-f->degree+k;Word suffix=part(f->lm,f->degree,f->degree-k,k);
  if(glen<=k||glen>=S.current){S.iter_k++;S.iter_ready=0;continue;}
  if(!S.iter_ready){S.iter_node=PTR(u32,S.prefix_heads)[prefix_hash(suffix,k,glen)];S.iter_ready=1;}
  while(S.iter_node){if((++polls&1023)==0){if(S.telemetry_enabled)(void)gn_host_clock();if(cancelled())return -GN_CANCELLED;}Prefix*q=prefix(S.iter_node);S.iter_node=q->next;u32 id=q->rule;if(id>S.degree_snapshot||q->length!=k)continue;Rule*g=rule(id);if(g->degree!=glen||!weq(part(g->lm,g->degree,0,k),suffix))continue;
   S.degree_seen++;
   if(S.pruning&&f->n==1&&g->n==1){S.zero_pairs++;S.degree_monomial++;continue;}
   if(S.chain_enabled&&matcher_interior(f,g,k)){S.chain_skipped++;S.degree_chain++;continue;}
   if(gm_pair(S.iter_f,id,k)){S.degree_chain++;continue;}
   l->f=S.iter_f;l->g=id;l->k=k;l->snapshot=S.nrules;l->error=0;S.pair_count++;S.degree_scheduled++;return 1;
  }
  S.iter_k++;S.iter_ready=0;
 }
 S.iter_done=1;return 0;
}
static int reduce_pair_impl(u32 lane){if(lane>=S.workers)return GN_INPUT;Lane*l=&S.lanes[lane];l->normal_valid=0;l->delta_floor=0;l->memory_wait=0;l->memory_need=0;l->memory_detail=0;l->reserve_direct=0;l->error=0;reset_a(&l->a[0]);reset_a(&l->a[1]);l->active=0;l->result=(Poly){0};l->pairs++;l->tail_generation=T.generation;l->tail_snapshot=l->snapshot;
 if(pair_replay_filter(l->f,l->g,l->k))return 0;
 if(fg_sector_pair(l))return 0;
 Rule*f=rule(l->f),*g=rule(l->g);u32 nr=g->degree-l->k;Word suffix=part(g->lm,g->degree,l->k,nr),left=part(f->lm,f->degree,0,f->degree-l->k);Poly fp=load_rule(l->f,l);if(l->error)return l->error;
 Poly p=copy_poly(fp,&l->a[0],(Word){0,0},suffix,nr,S.current);if(l->a[0].error)return l->a[0].error;Poly gp=load_rule(l->g,l);if(l->error)return l->error;Coef a=pc(gp,0),b=pc(p,0);Arena*ar=&l->a[1];Coef z=S.modulus?2:gcdc(ar,a,b);Coef sp=S.modulus?a:exactdiv(ar,a,z),sg=negf(S.modulus?b:exactdiv(ar,b,z));if(ar->error)return ar->error;
 l->result=combine(p,sp,gp,sg,left,(Word){0,0},0,ar);l->active=1;if(ar->error)return ar->error;int rc=nf(l,l->snapshot);l->error=rc;return rc;
}
API int gn_reduce_pair(u32 lane){
 if(lane>=S.workers)return GN_INPUT;Lane*l=&S.lanes[lane];l->busy=1;publish_lane(l,0,0);
 int rc=reduce_pair_impl(lane);if(!rc){l->normal_valid=1;l->normal_snapshot=l->snapshot;l->normal_degree=S.current;}l->busy=0;publish_lane(l,l->result.n,0);return rc;
}
API int gn_commit(u32 lane){if(lane>=S.workers)return GN_INPUT;Lane*l=&S.lanes[lane];if(l->error)return l->error;l->busy=2;publish_lane(l,l->result.n,0);int rc=commit_nf(l,S.nrules);if(!rc){double append_start=gn_host_clock();/* The coordinator I/O buffer must not overwrite a row in lane 0. */rc=S.certifying?(l->result.n?GN_REJECTED:0):append_rule(l->result,0,0);commit_elapsed(13,append_start);l->normal_valid=0;}l->error=rc;l->busy=0;if(!rc)S.degree_committed++;publish_lane(l,l->result.n,0);return rc;}
/* An epoch has an immutable basis. Workers dynamically claim pair descriptors.
 * Only the coordinator writes descriptors, commits rows or grows memory, and only
 * outside parallel epochs. Outputs live outside the reduction arenas. */
/* Prioritize larger input records inside the immutable batch. This heuristic
 * changes ONLY dispatch order. Task numbers and ordered exact commits stay put.
 * Stable bounded mergesort; no timing probes or polynomial data are required. */
static u64 batch_weight(u32 i){BatchTask*t=&S.tasks[i];return (u64)rule(t->f)->bytes+rule(t->g)->bytes;}
static void order_batch(void){
 S.batch_work_n=S.batch_n-S.batch_first;for(u32 i=0;i<S.batch_work_n;i++)S.batch_order[i]=i+S.batch_first;
 if(!S.cost_scheduling||S.workers<2)return;
 for(u32 span=1;span<S.batch_work_n;span*=2){
  for(u32 left=0;left<S.batch_work_n;left+=2*span){
   u32 mid=MIN(left+span,S.batch_work_n),end=MIN(left+2*span,S.batch_work_n),i=left,j=mid,k=left;
   while(i<mid||j<end){
    int takeleft=j==end||(i<mid&&batch_weight(S.batch_order[i])>=batch_weight(S.batch_order[j]));
    S.batch_sort[k++]=takeleft?S.batch_order[i++]:S.batch_order[j++];
   }
  }
  memcpy(S.batch_order,S.batch_sort,(size_t)S.batch_work_n*sizeof(u32));
 }
}
API int gn_batch_fill(u32 limit){
 if(!S.batch_enabled||!S.current||!limit||limit>BATCH_MAX)return -GN_STATE;
 if(S.spill)for(u32 i=0;i<S.workers;i++){int rc=ensure_rule_io(&S.lanes[i],S.largest_rule_bytes);if(rc)return -rc;}
 int tc=tail_cache_prepare();if(tc)return -tc;
 reserve_pool_admit();
 S.batch_n=0;S.batch_first=0;S.batch_committed=0;GN_STORE(&S.batch_next,0);
 for(u32 l=0;l<S.workers;l++)S.lanes[l].out_used=0;
 for(u32 i=0;i<limit;i++){
  int rc=gn_next_pair(0);if(rc<0)return rc;if(!rc)break;
  Lane*l=&S.lanes[0];S.tasks[i]=(BatchTask){l->f,l->g,l->k,l->snapshot,GN_STATE,0,0};S.batch_n++;
 }
 if(S.batch_n){S.batch_epochs++;order_batch();}return (int)S.batch_n;
}
API int gn_batch_reduce(u32 lane){
 if(lane>=S.workers||!S.batch_enabled)return GN_STATE;
 Lane*l=&S.lanes[lane];GN_FETCH_ADD(&S.batch_running,1);l->allow_repack=1;
 for(;;){
  u32 i=GN_FETCH_ADD(&S.batch_next,1);if(i>=S.batch_work_n)break;
  BatchTask*t=&S.tasks[S.batch_order[i]];l->f=t->f;l->g=t->g;l->k=t->k;l->snapshot=t->snapshot;
  int rc=gn_reduce_pair(lane);t->rc=(u32)rc;if(rc||!l->result.n)continue;
  if(S.certifying){t->rc=GN_REJECTED;continue;}
  u64 bytes=record_bytes(l->result);
  if(bytes>l->out_size-l->out_used||bytes>UINT32_MAX){t->rc=GN_BATCH_FULL;continue;}
  t->output=l->out_base+l->out_used;t->bytes=(u32)bytes;
  t->rc=(u32)write_record(l->result,t->output,bytes);
  if(!t->rc)l->out_used+=A8(bytes);
 }
 l->allow_repack=0;GN_FETCH_ADD(&S.batch_running,(u32)-1);return 0;
}
API u32 gn_batch_status(u32 task){return task<S.batch_n?S.tasks[task].rc:GN_INPUT;}
static int batch_commit_impl(u32 task){
 if(task>=S.batch_n)return GN_INPUT;BatchTask*t=&S.tasks[task];
 if(!t->rc&&t->bytes&&fg_sector_ids(t->f,t->g,t->k)){GN_FETCH_ADD(&S.fg_commit_skipped,1);S.commit_zero++;S.degree_committed++;return 0;}
 if(t->rc==GN_DEFERRED){
  /* Parallel readers are finished. Recompute this one deferred pair, with
   * its original snapshot, then run the ordinary updated-basis commit. */
  Lane*l=&S.lanes[0];l->f=t->f;l->g=t->g;l->k=t->k;l->snapshot=t->snapshot;
  int rc=gn_reduce_pair(0);if(rc)return rc;t->rc=0;return gn_commit(0);
 }
 if(t->rc)return (int)t->rc;if(!t->bytes){S.commit_zero++;S.degree_committed++;return 0;}
 Lane*l=&S.lanes[0];reset_a(&l->a[0]);reset_a(&l->a[1]);l->active=0;l->error=0;
 l->snapshot=t->snapshot;l->normal_valid=1;l->normal_snapshot=t->snapshot;l->normal_degree=S.current;l->delta_floor=0;l->resume_tier=0;
 double copy_start=gn_host_clock();
 Record*h=PTR(Record,t->output);
 Poly stored={t->output+sizeof(Record),h->n,h->degree,t->output};
 l->result=copy_poly(stored,&l->a[0],(Word){0,0},(Word){0,0},0,h->degree);
 GN_FETCH_ADD(&S.commit_metrics[11],t->bytes);commit_elapsed(12,copy_start);
 if(l->a[0].error)return l->a[0].error;
 return gn_commit(0);
}
/* Reconfiguration is coordinator-only after every reader joined. Committed
 * prefix rows stay in the basis; only uncommitted tasks are replayed with the
 * original immutable snapshots, followed by the usual exact commit reduction. */
API int gn_batch_commit(u32 task){
 if(task!=S.batch_committed||GN_LOAD(&S.batch_running))return GN_STATE;
 u32 before=S.nrules;S.lanes[0].allow_repack=1;int rc=batch_commit_impl(task);S.lanes[0].allow_repack=0;
 if(!rc){fg_note_pair_commit(S.tasks[task].f,S.tasks[task].g,S.tasks[task].k,before);S.batch_committed++;}return rc;
}
API int gn_batch_retry(u32 workers,u32 first){
 if(!S.auto_memory||!S.current||S.input_expected||GN_LOAD(&S.batch_running)||reserve_pool_busy()||!workers||workers>=S.workers||first!=S.batch_committed||first>=S.batch_n)return GN_STATE;
 int rc=layout_workers(workers,1);if(rc)return rc;
 for(u32 i=workers;i<S.lane_slots;i++){S.lanes[i].busy=0;publish_lane(&S.lanes[i],0,1);}
 for(u32 i=first;i<S.batch_n;i++){S.tasks[i].rc=GN_STATE;S.tasks[i].bytes=0;S.tasks[i].output=0;}
 S.batch_first=first;GN_STORE(&S.batch_next,0);order_batch();S.memory_retries++;S.memory_replayed_pairs+=S.batch_n-first;return 0;
}
API int gn_memory_policy(u32 enabled){if(enabled>1||S.current||S.input_expected||S.nrules)return GN_STATE;S.auto_memory=enabled;return 0;}
API u64 gn_memory_stat(u32 key){switch(key){case 0:return S.auto_memory;case 1:return S.lane_slots;case 2:return S.scratch_size;case 3:return S.memory_retries;case 4:return S.memory_replayed_pairs;case 5:return GN_LOAD(&S.batch_running);default:return 0;}}
API int gn_batch_fallback(void){S.batch_spills++;return gn_batch_mode(0);}
API int gn_finish_degree(void){if(!S.current||!S.iter_done)return GN_STATE;
 if(!S.gate_closed&&(S.degree_committed!=S.degree_scheduled||(S.degree_total_known&&S.degree_seen!=S.degree_total)))return GN_STATE;S.completed=S.current;S.current=0;S.gate_active=0;return 0;}
API u64 gn_rule_stat(u32 id,u32 key){if(!id||id>S.nrules)return 0;Rule*r=rule(id);switch(key){case 0:return r->lm.lo;case 1:return r->lm.hi;case 2:return r->degree;case 3:return r->n;case 4:return r->bytes;case 5:return r->location;default:return 0;}}
API u64 gn_export_rule(u32 id){if(!id||id>S.nrules)return 0;Lane*l=&S.lanes[0];l->error=0;Rule*r=rule(id);if(S.spill){int rc=ensure_rule_io(l,r->bytes);if(rc){l->error=rc;return 0;}if(!gn_host_read(r->location,l->io_base,r->bytes)){l->error=GN_IO;return 0;}if(validate_record(l->io_base,r->bytes)){l->error=GN_CORRUPT;return 0;}return l->io_base;}
 Poly p={r->location+sizeof(Record),r->n,r->degree,r->location};if(write_record(p,l->io_base,l->io_size)){l->error=GN_SCRATCH;return 0;}return l->io_base;}
API u32 gn_export_size(void){return PTR(Record,S.lanes[0].io_base)->bytes;}
API u64 gn_import_buffer(void){return S.lanes[0].io_base;}
API u32 gn_import_capacity(void){return(u32)MIN(S.lanes[0].io_size,UINT32_MAX);}
API int gn_restore_rule(u32 bytes,u64 file_offset){Lane*l=&S.lanes[0];if(bytes>l->io_size)return GN_SCRATCH;int rc=validate_record(l->io_base,bytes);if(rc)return rc;Record*h=PTR(Record,l->io_base);Poly p={l->io_base+sizeof(Record),h->n,h->degree,l->io_base};return append_rule(p,file_offset,1);}
API int gn_restored_through(u32 degree){if(S.current||degree>S.target||(S.nrules&&rule(S.nrules)->degree>degree))return GN_STATE;S.completed=degree;return 0;}
API i64 gn_test_small(u32 operation,i64 a,i64 b){Lane*l=&S.lanes[0];reset_a(&l->a[0]);Coef x=csmall(a),y=csmall(b),z=0;if(operation==0)z=addc(&l->a[0],x,y);else if(operation==1)z=mulc(&l->a[0],x,y);else if(operation==2)z=gcdc(&l->a[0],x,y);else if(operation==3)z=exactdiv(&l->a[0],mulc(&l->a[0],x,y),x);return z&1?INT64_MIN:cvalue(z);}

/* A reconstructed candidate is untrusted until ALL required degrees, input
 * membership tests, and the host's independent homogeneous rank-bound witness
 * succeed. This flag never turns a failed composition into a new basis rule. */
API int gn_candidate_check(void){
 if(S.current||S.input_expected||S.modulus)return GN_STATE;
 Lane*l=&S.lanes[0];l->skip_rule=0;int rc=matcher_build();if(rc)return rc;
 for(u32 id=1;id<=S.nrules;id++){
  if((id&255)==0&&cancelled())return GN_CANCELLED;
  u32 pos=0;if(divisor(rule(id)->lm,rule(id)->degree,S.nrules,&pos,l)!=id)return GN_REJECTED;
 }
 S.certifying=1;S.completed=0;return 0;
}
API u32 gn_is_certifying(void){return S.certifying;}
/* Coordinator prepares the immutable index once; independent lanes may then
 * normalize rows concurrently. Neither rule records nor checkpoints are edited.
 * The serialized result lives in that lane's I/O buffer until its next call. */
API int gn_normalize_prepare(void){
 if(S.current||S.input_expected||S.certifying||GN_LOAD(&S.batch_running)||reserve_pool_busy())return GN_STATE;
 int rc=matcher_build();if(!rc)S.canonical_snapshot=S.nrules;return rc;
}
API u64 gn_normalize_rule(u32 lane,u32 id){
 if(lane>=S.workers)return 0;
 Lane*l=&S.lanes[lane];l->error=0;
 if(S.current||S.input_expected||S.certifying||S.canonical_snapshot!=S.nrules||!id||id>S.nrules){l->error=GN_STATE;return 0;}
 l->skip_rule=0;l->slice_enabled=0;l->resume_tier=0;l->allow_repack=0;l->tail_generation=T.generation;l->tail_snapshot=S.nrules;
 l->delta_floor=0;l->normal_valid=0;
 l->busy=1;l->f=id;l->g=0;l->k=0;
 int rc=0;
 if(cancelled()){rc=GN_CANCELLED;goto done;}
 u32 pos=0;if(divisor(rule(id)->lm,rule(id)->degree,S.nrules,&pos,l)!=id){rc=GN_REJECTED;goto done;}
 reset_a(&l->a[0]);reset_a(&l->a[1]);l->active=0;
 Poly input=load_rule(id,l);if(l->error){rc=l->error;goto done;}
 /* Already normal tails (including all monomial rules) need no arithmetic,
  * polynomial copy or heap construction. This is common in large FK bases. */
 u32 j=1;
 for(;j<input.n;j++){
  if(!(j&255)&&cancelled()){rc=GN_CANCELLED;goto done;}
  if(divisor(pw(input,j),input.degree,S.nrules,&pos,l))break;
 }
 if(j==input.n){if(input.origin!=l->io_base)rc=write_record(input,l->io_base,l->io_size);goto done;}
 l->result=copy_poly(input,&l->a[0],(Word){0,0},(Word){0,0},0,input.degree);
 if(l->a[0].error){rc=l->a[0].error;goto done;}
 l->skip_rule=id;rc=nf(l,S.nrules);l->skip_rule=0;
 if(!rc&&(!l->result.n||!weq(pw(l->result,0),rule(id)->lm)))rc=GN_REJECTED;
 if(!rc)rc=write_record(l->result,l->io_base,l->io_size);
done:
 l->skip_rule=0;l->busy=0;l->error=rc;publish_lane(l,0,1);return rc?0:l->io_base;
}
API u32 gn_normalize_status(u32 lane){return lane<S.workers?S.lanes[lane].error:GN_STATE;}
API u64 gn_canonical_rule(u32 id){
 int rc=gn_normalize_prepare();if(rc){S.lanes[0].error=rc;return 0;}
 return gn_normalize_rule(0,id);
}
/* Ephemeral exact numerator/denominator pair for native text formatting.
 * Exported row remains intact in I/O; arithmetic uses an otherwise idle arena.
 * Hosts must consume the pair before normalizing/formatting the next term. */
API u64 gn_monic_coefficient(u32 lane,u32 index){
 if(lane>=S.workers)return 0;
 Lane*l=&S.lanes[lane];Record*h=PTR(Record,l->io_base);l->error=0;
 if(l->busy||h->magic!=MAGIC||index>=h->n){l->error=GN_STATE;return 0;}
 reset_a(&l->a[0]);Arena*a=&l->a[0];
 u64 off=alloc_a(a,2*sizeof(Coef));if(!off){l->error=a->error;return 0;}
 Poly p={l->io_base+sizeof(Record),h->n,h->degree,l->io_base};
 Coef c=pc(p,index),lead=pc(p,0);
 if(!index){PTR(Coef,off)[0]=PTR(Coef,off)[1]=csmall(1);return off;}
 if(S.modulus||lead==csmall(1)){PTR(Coef,off)[0]=c;PTR(Coef,off)[1]=csmall(1);return off;}
 Coef g=gcdc(a,c,lead);
 Coef num=S.modulus?c:exactdiv(a,c,g),den=S.modulus?csmall(1):exactdiv(a,lead,g);
 if(csign(den)<0){num=cneg(num);den=cneg(den);}
 PTR(Coef,off)[0]=num;PTR(Coef,off)[1]=den;
 l->error=a->error;return a->error?0:off;
}
#include "hilbert.inc"
#include "hilbert_gate.inc"
#include "fk_gate.inc"
#include "lower_bound.inc"

#ifndef __wasm__
/* Native-only independent arithmetic property-test hook. */
API int gn_test_rational(u32 op,i64 an,u64 ad,i64 bn,u64 bd,i64*on,u64*od){
 if(op>1||!ad||!bd||ad>(u64)SMALL_MAX||bd>(u64)SMALL_MAX||an>SMALL_MAX||an< -SMALL_MAX||bn>SMALL_MAX||bn< -SMALL_MAX||rgcd(rabs(an),ad)!=1||rgcd(rabs(bn),bd)!=1)return -1;
 RCoef out;int ok=op?rmul((RCoef){an,ad},(RCoef){bn,bd},&out):radd((RCoef){an,ad},(RCoef){bn,bd},&out);
 if(ok){*on=out.n;*od=out.d;}return ok;
}
#endif

API int gn_pin_cache(u64 bytes){
 if(S.current||S.input_expected||S.nrules||S.pin_base)return GN_STATE;
 if(!bytes||!S.spill)return 0;
 bytes&=~UINT64_C(7);
 if(!bytes||bytes>S.budget-S.bump||!gn_host_ensure(S.bump+bytes))return 0;
 S.pin_base=S.bump;S.pin_capacity=bytes;S.bump+=bytes;S.allocated_peak=MAX(S.allocated_peak,S.bump);return 0;
}

API int gn_local_rewrites(u32 degree,u64 bytes,u32 support){
 if(S.current||S.input_expected||S.nrules||S.local_base||degree>4||degree==1||support<1||support>64)return GN_INPUT;
 if(!degree||!bytes)return 0;
 bytes=MIN(bytes,S.budget/8);bytes=A8(bytes);
 if(bytes>S.budget-S.bump||!gn_host_ensure(S.bump+bytes))return 0;
 S.local_base=S.bump;S.local_capacity=bytes;S.local_degree=degree;S.local_limit=support;S.bump+=bytes;S.allocated_peak=MAX(S.allocated_peak,S.bump);return 0;
}

/* Export a compiled identity w - sum c_i*v_i for independent audit.
 * The degree/basis is not changed. Valid only at an idle degree boundary. */
API u64 gn_local_rule(u32 key){
 if(S.current||S.input_expected||S.local_built!=1||key>=(1u<<(4*S.local_degree)))return 0;
 LocalEntry*entry=&PTR(LocalEntry,S.local_base)[key];if(!entry->off)return 0;
 Lane*l=&S.lanes[0];reset_a(&l->a[0]);l->error=0;
 u64 off=alloc_a(&l->a[0],(u64)(entry->n+1)*sizeof(Term));if(l->a[0].error)return 0;
 Term*t=PTR(Term,off);t[0]=(Term){{key,0},2};LocalTerm*lt=PTR(LocalTerm,S.local_base+entry->off);
 for(u32 j=0;j<entry->n;j++)t[j+1]=(Term){{lt[j].word,0},negf(csmall(lt[j].c))};
 Poly p={off,entry->n+1,S.local_degree,0};int rc=write_record(p,l->io_base,l->io_size);l->error=rc;return rc?0:l->io_base;
}

/* Optional exact macro reuse in the compact rational fallback, 0.6.1. */
API int gn_rational_rewrites(u32 enabled){if(enabled>1)return GN_INPUT;if(S.nrules||S.current||S.input_expected)return GN_STATE;S.rational_rewrites=!!enabled;return 0;}
API u64 gn_deep_stat(u32 lane,u32 key){if(lane>=S.lane_slots)return 0;Lane*l=&S.lanes[lane];switch(key){case 0:return l->rational_local_hits;case 1:return l->rational_space_misses;case 2:return l->rational_coefficient_misses;case 3:return l->rational_arithmetic_misses;case 4:return l->rational_table_retries;default:return 0;}}

/* Immutable field identity for audit/harness checks. */
API u32 gn_modulus(void){return S.modulus;}

/* Idle-only tuning: 0 = normalized limb division, 1 = 0.6.1 bitwise reference. */
API int gn_legacy_big_division(u32 enabled){if(enabled>1)return GN_INPUT;if(S.nrules||S.current||S.input_expected)return GN_STATE;S.legacy_big_division=enabled;return 0;}
/* Arithmetic audit hook. Inputs/outputs use little-endian magnitude limbs in
 * the existing I/O buffer; no host pointers or decimal rounding are involved. */
API int gn_test_big(u32 op,u32 na,u32 nb,int sa,int sb){
 Lane*l=&S.lanes[0];Arena*a=&l->a[0];reset_a(a);
 if(op>5||!na||!nb||(sa!=1&&sa!=-1)||(sb!=1&&sb!=-1)||((u64)na+nb)*4>l->io_size)return -GN_INPUT;
 Coef x=makec(a,PTR(u32,l->io_base),na,sa),y=makec(a,PTR(u32,l->io_base)+na,nb,sb),r=0;
 if(op==0)r=addc(a,x,y);else if(op==1)r=mulc(a,x,y);else if(op==2)r=divmodc(a,x,y,1);else if(op==3)r=divmodc(a,x,y,0);else if(op==4)r=gcdc(a,x,y);else r=exactdiv(a,x,y);
 if(a->error)return -(int)a->error;u32 n=cn(r);if(8+(u64)n*4>l->io_size)return -GN_SCRATCH;
 PTR(u32,l->io_base)[0]=n;PTR(i64,l->io_base)[0]=(i64)n|((u64)(csign(r)<0)<<32);
 for(u32 i=0;i<n;i++)PTR(u32,l->io_base+8)[i]=cl(r,i);return 0;
}

API int gn_big_rational_heap(u32 enabled){if(enabled>1)return GN_INPUT;if(S.nrules||S.current||S.input_expected)return GN_STATE;S.big_rational_enabled=enabled;return 0;}
API int gn_big_row_limit(u32 terms){if(terms&&(terms<128||terms>(1u<<30)||(terms&(terms-1))))return GN_INPUT;if(S.nrules||S.current||S.input_expected)return GN_STATE;S.big_row_max_terms=terms;return 0;}
API u64 gn_exact_stat(u32 lane,u32 key){if(lane>=S.lane_slots)return 0;Lane*l=&S.lanes[lane];switch(key){case 0:return l->big_attempts;case 1:return l->big_successes;case 2:return l->big_fallbacks;case 3:return l->big_steps;case 4:return l->big_compactions;case 5:return l->big_pool_misses;case 6:return l->big_capacity_misses;case 7:return l->big_arena_misses;case 8:return S.big_rational_enabled;case 9:return S.legacy_big_division;case 10:return l->rational_table_growths;case 11:return S.growing_rational;case 12:return l->big_growths;case 13:return l->big_peak_terms;case 14:return l->big_capacity;case 15:return l->big_reserved;case 16:return l->big_coefficient_live;case 17:return l->big_coefficient_bytes;case 18:return S.big_row_max_terms;case 19:return l->big_reserve_waits;case 20:return l->general_fallbacks;case 21:return l->big_pool_high_water;case 22:return l->big_arithmetic_high_water;case 23:return l->big_collected_live_high_water;default:return 0;}}

API int gn_growing_rational(u32 enabled){if(enabled>1)return GN_INPUT;if(S.nrules||S.current||S.input_expected)return GN_STATE;S.growing_rational=enabled;return 0;}

/* Test exact rational arithmetic using four magnitude limb arrays, independent
 * from the normal-form test harness. Input arrays: numerator/denominator A/B. */
API int gn_test_big_fraction(u32 op,u32 an,u32 ad,u32 bn,u32 bd,int sa,int sb){
 Lane*l=&S.lanes[0];Arena*t=&l->a[0];reset_a(t);
 if(op>1||!an||!ad||!bn||!bd||sa*sa!=1||sb*sb!=1||((u64)an+ad+bn+bd)*4>l->io_size)return -GN_INPUT;
 u32*v=PTR(u32,l->io_base);Coef a=makec(t,v,an,sa),d=makec(t,v+an,ad,1),b=makec(t,v+an+ad,bn,sb),e=makec(t,v+an+ad+bn,bd,1);
 BCoef x=bmake(t,a,d),y=bmake(t,b,e),r=op?bmul(t,x,y):badd(t,x,y);
 if(t->error)return -(int)t->error;u32 n=cn(r.n),dn=cn(r.d);if(16+((u64)n+dn)*4>l->io_size)return -GN_SCRATCH;
 v[0]=n;v[1]=dn;v[2]=csign(r.n)<0;v[3]=0;
 for(u32 i=0;i<n;i++)v[4+i]=cl(r.n,i);for(u32 i=0;i<dn;i++)v[4+n+i]=cl(r.d,i);return 0;
}

/* Configure at initialization only. Reservation is bounded by the kernel
 * budget and optional: a budget/host denial never corrupts the base solver. */
API int gn_row_reserve(u64 bytes){
 if(S.current||S.input_expected||S.nrules||S.reserve_base)return GN_STATE;
 bytes&=~UINT64_C(7);if(!bytes||S.modulus)return 0;
 if(bytes>S.budget-S.bump||!gn_host_ensure(S.bump+bytes))return 0;
 S.reserve_base=S.bump;S.reserve_bytes=bytes;S.reserve_initial_bytes=bytes;S.bump+=bytes;S.allocated_peak=MAX(S.allocated_peak,S.bump);return 0;
}
API int gn_commit_row_reserve(u64 bytes){
 if(S.current||S.input_expected||S.nrules||S.commit_reserve_configured)return GN_STATE;
 S.commit_reserve_configured=1;bytes&=~UINT64_C(65535);
 if(!bytes||S.modulus)return 0;
 u64 base=workspace_take(&bytes);if(!base)return GN_MEMORY;
 S.commit_reserve_base=base;S.commit_reserve_bytes=bytes;return 0;
}
API int gn_reserve_pool(u32 count){
 if(count>GN_RESERVE_SLOTS)return GN_INPUT;
 if(S.current||S.input_expected||S.nrules||GN_LOAD(&S.batch_running)||reserve_pool_busy())return GN_STATE;
 S.reserve_pool_limit=count;return 0;
}
API u64 gn_reserve_pool_stat(u32 key){
 u64 total=S.reserve_base?S.reserve_bytes:0;
 for(u32 i=0;i<S.reserve_extra_count;i++)total+=S.reserve_extra_bytes[i];
 switch(key){case 0:return (S.reserve_base?1+S.reserve_extra_count:0)+(S.commit_reserve_base?1:0);case 1:return reserve_pool_limit()+(S.commit_reserve_base?1:0);
 case 2:return total+S.commit_reserve_bytes;case 3:return total-(S.reserve_base?S.reserve_bytes:0);
 case 4:return reserve_pool_busy();case 5:return S.reserve_pool_admissions;case 6:return S.reserve_pool_declines;
 case 7:return GN_LOAD(&S.reserve_pool_requested);case 8:return S.commit_reserve_bytes;
 case 9:return GN_LOAD(&S.commit_reserve_lock);default:return 0;}
}
API u64 gn_reserve_stat(u32 lane,u32 key){
 if(key==0)return S.reserve_bytes;if(lane>=S.lane_slots)return 0;Lane*l=&S.lanes[lane];
 switch(key){case 1:return l->reserve_attempts;case 2:return l->reserve_successes;case 3:return l->reserve_busy;case 4:return l->reserve_misses;case 5:return l->reserve_peak;case 6:return l->reserve_promotions;case 7:return S.reserve_growth;case 8:return S.radix_enabled;case 9:return !!reserve_pool_busy();default:return 0;}
}

API int gn_reserve_growth(u32 enabled){if(enabled>1)return GN_INPUT;if(S.current||S.input_expected||S.nrules)return GN_STATE;S.reserve_growth=enabled;return 0;}

API int gn_radix_queue(u32 enabled){if(enabled>1)return GN_INPUT;if(S.current||S.input_expected||S.nrules)return GN_STATE;S.radix_enabled=enabled;return 0;}

#include "frontier.inc"

#include "cooperative.inc"

API int gn_pair_plan_config(u32 order,u32 min_degree,u64 bytes){
 if(order>4||!min_degree||min_degree>GN_INDEX_MAX||S.current||S.input_expected||S.nrules)return GN_INPUT;
 P.requested=order;P.min_degree=min_degree;P.budget=MIN(bytes,S.budget/8);return 0;
}
API int gn_pair_plan_adopt(void){
 if(!P.requested||!S.current||S.current<P.min_degree||P.active)return 0;
 if(S.input_expected||GN_LOAD(&S.batch_running)||reserve_pool_busy()||C.commit_task)return -GN_STATE;
 for(u32 i=0;i<S.workers;i++)if(S.lanes[i].resume_tier||GN_LOAD(&C.assigned[i]))return -GN_STATE;
 u32 pending=S.batch_n-S.batch_committed;
 for(u32 i=0;i<pending;i++)if(S.tasks[S.batch_committed+i].rc!=GN_STATE&&S.tasks[S.batch_committed+i].rc!=GN_DEFERRED)return -GN_STATE;
 if(S.degree_scheduled<S.degree_committed||S.degree_scheduled-S.degree_committed!=pending)return -GN_STATE;
 u64 seen=S.degree_seen;
 int rc=plan_build(P.requested,seen,&S.tasks[S.batch_committed],pending);if(rc<=0)return rc;
 /* Only pending work is put back in the candidate pool. All committed input
  * basis bytes and every already-committed pair remain retained. */
 S.degree_seen-=pending;S.degree_scheduled-=pending;S.pair_count-=pending;
 S.batch_n=S.batch_first=S.batch_committed=S.batch_work_n=0;GN_STORE(&S.batch_next,0);
 S.iter_f=1;S.iter_k=1;S.iter_node=S.iter_ready=0;S.iter_done=P.count==0;P.adoptions++;return 1;
}
API int gn_pair_plan_reorder(void){
 if(!P.requested||!P.active||!S.current||P.mode==P.requested)return 0;
 if(S.input_expected||GN_LOAD(&S.batch_running)||reserve_pool_busy()||C.commit_task)return -GN_STATE;
 for(u32 i=0;i<S.workers;i++)if(S.lanes[i].resume_tier||GN_LOAD(&C.assigned[i]))return -GN_STATE;
 u32 pending=S.batch_n-S.batch_committed;
 if(pending>BATCH_MAX||S.degree_scheduled<S.degree_committed||S.degree_scheduled-S.degree_committed!=pending)return -GN_STATE;
 BatchTask*task=&S.tasks[S.batch_committed];
 for(u32 i=0;i<pending;i++)if(task[i].rc!=GN_STATE&&task[i].rc!=GN_DEFERRED)return -GN_STATE;
 int rc=plan_check_pending(task,pending);if(rc)return -rc;
 u64 remaining=(u64)P.count-P.cursor+pending,baseline=S.degree_seen-pending;
 if(remaining>P.capacity||baseline>P.total||remaining!=P.total-baseline)return -GN_CORRUPT;
 u32 bytes=(u32)((P.total+7)/8);
 if((u64)FH*8+pending*16+bytes>MIN(S.lanes[0].io_size,GN_FRONTIER_MAX_BYTES)||bytes>P.budget-P.allocated)return -GN_MEMORY;
 /* Allocate separately before changing the active plan. All subsequent work is
  * bounded and cannot fail; a stop signal is handled after migration finishes. */
 u64 bitmap=alloc_p(bytes);if(!bitmap)return -GN_MEMORY;
 PlanPair saved[BATCH_MAX],*t=PTR(PlanPair,P.base);u32 found=0;
 u32 slots[1024]={0};for(u32 i=0;i<pending;i++){u32 h=plan_hash(task[i].f,task[i].g,task[i].k);while(slots[h])h=(h+1)&1023;slots[h]=i+1;}
 for(u32 i=0;i<P.cursor;i++){u32 h=plan_hash(t[i].f,t[i].g,t[i].k);while(slots[h]){u32 j=slots[h]-1;if(t[i].f==task[j].f&&t[i].g==task[j].g&&t[i].k==task[j].k){saved[found++]=t[i];break;}h=(h+1)&1023;}}
 u8*bits=PTR(u8,bitmap);memset(bits,255,bytes);if(P.total&7)bits[bytes-1]=(u8)((1u<<(P.total&7))-1);
 u32 tail=P.count-P.cursor;
 for(u32 i=P.cursor;i<P.count;i++)bits[t[i].ordinal>>3]&=(u8)~(1u<<(t[i].ordinal&7));
 for(u32 i=0;i<found;i++)bits[saved[i].ordinal>>3]&=(u8)~(1u<<(saved[i].ordinal&7));
 memmove(t,t+P.cursor,(u64)tail*sizeof(PlanPair));memcpy(t+tail,saved,(u64)pending*sizeof(PlanPair));
 P.count=tail+pending;P.cursor=0;P.mode=P.requested;P.gate_ready=0;
 for(u32 i=P.count/2;i--;)plan_sift(t,i,P.count,P.mode);
 for(u32 i=P.count;i>1;){PlanPair x=t[0];t[0]=t[--i];t[i]=x;plan_sift(t,0,i,P.mode);}
 P.excluded_base=bitmap;P.excluded_bytes=bytes;P.excluded_count=baseline;P.allocated+=bytes;P.anchor_n=0;P.anchor_seen=baseline;
 S.degree_seen-=pending;S.degree_scheduled-=pending;S.pair_count-=pending;
 S.batch_n=S.batch_first=S.batch_committed=S.batch_work_n=0;GN_STORE(&S.batch_next,0);
 S.iter_f=1;S.iter_k=1;S.iter_node=S.iter_ready=0;S.iter_done=P.count==0;P.adoptions++;return 1;
}
API u64 gn_pair_plan_stat(u32 key){switch(key){case 0:return P.active;case 1:return P.mode;case 2:return P.count;case 3:return P.cursor;case 4:return P.total;case 5:return P.anchor_seen;case 6:return P.anchor_n;case 7:return P.allocated;case 8:return P.builds;case 9:return P.declines;case 10:return P.adoptions;case 11:return P.build_us;case 12:return P.gate_replans;case 13:return P.gate_ready;case 14:return P.q14_hint;case 15:return P.gate_target;case 16:return P.gate_injected;case 17:return P.gate_stride;case 18:return P.excluded_bytes;case 19:return P.excluded_count;
 case 20:return P.gate_target<360?P.gate_attempts[P.gate_target]:0;
 case 21:return P.gate_target<360?P.gate_successes[P.gate_target]:0;
 case 22:return P.gate_cooldowns;
 case 23:return S.current&&P.gate_degree==S.current&&P.gate_target<360&&S.fg_sector_ready?S.fg_sector_upper[P.gate_target]-fg_lower_group(S.current,P.gate_target):0;
 case 24:return C.finisher_selected;case 25:return C.finisher_held;case 26:return MIN(2u,S.workers);default:return 0;}}
API int gn_q14_hint(u32 enabled){if(enabled>1||S.current||S.input_expected||S.nrules)return GN_STATE;P.q14_hint=enabled;return 0;}

API int gn_delta_commit(u32 enabled){if(enabled>1||S.nrules||S.current||S.input_expected||GN_LOAD(&S.batch_running))return GN_STATE;S.delta_commit=enabled;return 0;}
API u64 gn_commit_stat(u32 key){if(key==0)return S.delta_commit;return key<16?GN_LOAD(&S.commit_metrics[key]):0;}

/* Supported ordering modes as a bitset; host ABI guard for mode 3. */
API u32 gn_pair_plan_modes(void){return 31;}
