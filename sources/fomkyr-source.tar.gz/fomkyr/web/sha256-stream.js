// SPDX-License-Identifier: MIT
// Incremental SHA-256 keeps multi-gigabyte result exports outside the JS heap.
const K=Uint32Array.from([0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2]);
const rotate=(x,n)=>(x>>>n)|(x<<(32-n));
export class SHA256 {
  constructor(){this.h=Uint32Array.from([0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19]);this.w=new Uint32Array(64);this.tail=new Uint8Array(64);this.used=0;this.bytes=0;this.done=false;}
  block(b,at=0){
    const w=this.w;
    for(let i=0;i<16;i++){const p=at+4*i;w[i]=(b[p]<<24)|(b[p+1]<<16)|(b[p+2]<<8)|b[p+3];}
    for(let i=16;i<64;i++){const x=w[i-15],y=w[i-2];w[i]=(w[i-16]+(rotate(x,7)^rotate(x,18)^(x>>>3))+w[i-7]+(rotate(y,17)^rotate(y,19)^(y>>>10)))>>>0;}
    let [a,c0,c,d,e,f,g,h]=this.h;
    for(let i=0;i<64;i++){const t1=(h+(rotate(e,6)^rotate(e,11)^rotate(e,25))+((e&f)^((~e)&g))+K[i]+w[i])>>>0,t2=((rotate(a,2)^rotate(a,13)^rotate(a,22))+((a&c0)^(a&c)^(c0&c)))>>>0;h=g;g=f;f=e;e=(d+t1)>>>0;d=c;c=c0;c0=a;a=(t1+t2)>>>0;}
    const values=[a,c0,c,d,e,f,g,h];for(let i=0;i<8;i++)this.h[i]=(this.h[i]+values[i])>>>0;
  }
  update(bytes){
    if(this.done)throw Error('SHA-256 already finalized');this.bytes+=bytes.length;let at=0;
    if(this.used){const n=Math.min(64-this.used,bytes.length);this.tail.set(bytes.subarray(0,n),this.used);this.used+=n;at=n;if(this.used===64){this.block(this.tail);this.used=0;}}
    while(at+64<=bytes.length){this.block(bytes,at);at+=64;}
    if(at<bytes.length){this.tail.set(bytes.subarray(at));this.used=bytes.length-at;}return this;
  }
  hex(){
    if(this.done)throw Error('SHA-256 already finalized');this.done=true;
    const n=this.used;this.tail[n]=128;this.tail.fill(0,n+1);
    if(n>=56){this.block(this.tail);this.tail.fill(0);}
    new DataView(this.tail.buffer).setBigUint64(56,BigInt(this.bytes)*8n);this.block(this.tail);
    return [...this.h].map(x=>x.toString(16).padStart(8,'0')).join('');
  }
}
export async function blobSHA256(blob,onProgress){
  const hash=new SHA256(),reader=blob.stream().getReader();let bytes=0,yielded=0;
  try{for(;;){const {value,done}=await reader.read();if(done)break;hash.update(value);bytes+=value.length;yielded+=value.length;onProgress?.(bytes,blob.size);if(yielded>=8*1048576){yielded=0;await new Promise(r=>setTimeout(r,0));}}}
  finally{reader.releaseLock();}
  if(bytes!==blob.size)throw Error('File changed while hashing');return hash.hex();
}
