# Source review: Bergman and OCaml Bergman

Reviewed 2026-09-30. Paths below refer to the unmodified upstream sources,
not generated engine files. The patched distribution is **bergman-1.001-fix**;
fixed behavior is the default, and `(SETLEGACYMODE T)` selects the original
behavior and restores the original version identity.

George 0.2 also repairs the Common Lisp reader's error recovery and the ECL
bridge's recovery from unavailable keyboard input. The investigation and
native/Wasm/browser evidence are in [READER-FIX.md](READER-FIX.md).

## October 1 boundary corrections

The 0.4 LHS audit found a weighted elimination hang and two one-generator
matrix-order Hilbert errors in all three backends. Fresh native SBCL
reproduced them, while Singular returned the expected ideals and dimensions.
The corrections in `ports/common/behavior-patches.py` apply to build copies:

- `PLUSNOEVAL`, aliased by commutative `TOTALDEGREE`, now accepts zero or
  one exponent as well as the original multi-exponent case.
- Noncommutative elimination comparators return false for equal words.
  The elimination and inverse-elimination scans hold a shorter word's
  terminal 0 until both scans end. Equal weighted degrees need not have
  equal word lengths; advancing to NIL previously caused an infinite loop.
- A proper one-generator commutative quotient has a finite Hilbert
  polynomial. Its numerator's exponents now include the generator weight,
  correcting the formerly unweighted printed series in this boundary case.

These arithmetic/comparison boundary corrections apply in **both modes**.
Legacy continues to select the original computational branches for the
previously documented algorithmic defects. Unequal-word ordering and the
historical sequential outputs are checked for compatibility. The original
vendor tree remains unchanged. [BACKENDS.md](BACKENDS.md) documents the
Singular, native and browser checks and their degree-bound scope.

## Sources and scope

- `vendor/bergman-1.001`: Bergman 1.001, August 2007, Standard Lisp,
  approximately 29,000 lines. The Common Lisp/CLISP build is the porting base.
- [smimram/ocaml-alg](https://github.com/smimram/ocaml-alg), revision
  `365708af85d2faa50250414247179b3bc2bd13df` (2026-07-05). The inspected
  checkout is `build/oracles/ocaml-alg`; the web interface is in
  `tools/bergman/bergmanjs.ml`. This is an independent implementation.
- Singular 4.4.1, including its free algebra/Letterplace and Plural facilities,
  provides an independent ideal-membership oracle. Its monomial order and
  truncation bound must agree with the comparison being made.

## Original Bergman

`src/main.sl` implements degreewise and itemwise critical-pair processing.
`src/coeff.sl`, `char0.sl`, `char2.sl`, `odd.sl`, and `logodd.sl` provide exact
characteristic-zero arithmetic and prime-field arithmetic. The optional
modules cover Hilbert and Poincaré–Betti series, Anick resolutions, module
and factor-algebra homology, Hochschild computations, homogenization and
alternative strategies.

Relevant details found in the sources:

1. `CLEARRING` in `auxil/topproc.sl` does not restore all modes. In particular,
   degree limits and processing strategy can survive a calculation. George
   therefore gives each form computation a fresh worker/session.
2. `NCPBHDED` computes a PB series but its file remains empty when
   `IMMEDIATEASSOCRINGPBDISPLAY` is off. That is also the behavior of the
   bundled 2007 CLISP results. The default overlay enables the display
   temporarily; legacy mode preserves the empty file.
3. The two itemwise kernels in `src/main.sl` omit a pending-work degree-bound
   check, although some critical-pair generators already apply a bound.
   Default mode now stops before processing the next degree above MAXDEG;
   legacy mode retains the original control flow.
4. `stableMaybeReduceRedor` contains `(MONLESSP (APol2Lpmon ap pm))` instead
   of `(MONLESSP (APol2Lpmon ap) pm)`. `instableMaybeReduceRedor` puts the
   final two arguments of `LPUT!-LGET` inside `Maplst`. The build copy has
   corrected branches in default mode and original branches in legacy mode.
   The corrected traversal also guards an exhausted polynomial tail.
   `safenoncommMonTimes` fails for `left * 1 * right`: its three-word helper
   inserts the unit's terminator inside the product. Default mode joins the
   left and right words directly. The symmetric-group example exposed this
   defect, and now passes independent critical-pair and Singular checks.
5. Itemwise processing does not call the degree-end Anick update. Its
   degree-output file can be empty. An itemwise computation must export the
   final basis explicitly. A resolution must then be constructed from the
   completed basis using the degreewise resolution machinery.
6. In safe degreewise noncommutative mode, `MONLESSP` still uses the
   equal-degree lexicographic shortcut. Mixed-degree braid S-polynomials
   can retain a false `aba-aba` reductor and make normal-form reduction
   loop. Default mode uses the configured full order; a runtime legacy
   switch restores the original shortcut.
7. Anick's degree-left-lex tensor shortcut ignores the right coefficient
   word. In nonhomogeneous calculations its chosen term can be unprolongable.
   Default safe mode compares complete tensor words, merges by chain
   identity, and restores their order after multiplication and addition.
   See [the braid investigation](BRAID-FIX.md) for both reproducers and the
   independent projectivity certificate.
   Fresh factor-algebra and Hochschild jobs also need their resolution group
   loaded before setting additional-relation callbacks. The old sequential
   suite already loaded it in earlier cases; isolated form-preset checks
   exposed the missing initialization, now explicit in the session builder.
8. The additional Singular/Plural tests exposed defects in itemwise
   nonhomogeneous inclusion processing. `instableitemFixNGbe` only subtracts
   exact tail terms, missing old leading words divisible by a new one.
   Default mode records and schedules these inclusions, invalidates stale
   `LRReduced` markers and handles the saved `GbFactors` before overlap work.
   The formerly unused `instableMaybeReduceRedor` path also had a malformed
   property call and an undefined `GETAUGMONPROP` call. Its default path uses
   direct property assignment, the real leading monomial and the pure
   polynomial representation required by `SubtractRedor1`.
9. `NewReductSignature` splices a degree block into the signature instead
   of wrapping it as a list element. `MaybeFindGroebF` then traverses the
   generation marker as a list of degrees and misreads degree blocks.
   Default signatures preserve the list shape; a stale generation triggers
   a scan of the complete current basis. The generation marker still avoids
   scanning when the basis has not changed. Refresh returns the reductor or
   signature itself, not `PutMpt`'s property-header return value, which the
   caller would otherwise install as a self-referential pointer. The original
   eight-loop traversal remains in legacy mode.
10. `PutExtraNGroeb` receives its factor and target in reverse order in the
    noncommutative caller, relies on the undefined return value of an
    in-place conversion, and nests redirected pointer lists. Default mode
    keeps the reductand, passes the factor first, stores a flat pointer list
    directly, and guards self reduction. Critical pairs must also preserve
    their original overlap occurrence when a pointer redirects to a shorter
    leading word. `GEORGECRITQUOTIENT` adjusts that occurrence by the shorter
    factor's position in the old word; choosing the first occurrence would
    incorrectly erase self-overlaps.
11. Safe noncommutative multiplication needs structural unit detection in
    every empty/nonempty context, not pointer equality with one canonical
    unit. The lexicographic comparator needs an equal-word guard; otherwise
    it walks past both terminators forever. The guards preserve original
    behavior in legacy mode. Commutative comparison also
    follows process changes dynamically: original `SETITEMWISE` does not
    refresh the comparator selected by the preceding `COMMIFY`, so a
    nonhomogeneous graded-lexicographic form job could actually use pure lex.
    Empty commutative pair and cone lists are handled explicitly.
    The unstable commutative path processes all saved pairs: its original
    component pruning assumes stable leading words, an assumption lost after
    redirecting reductors. The minimum-polynomial example over F₂ exposed
    a missing degree-3 S-polynomial. Legacy keeps the
    original pruning. The imported Lie quotients and braid cases exercise
    these paths; see [UPSTREAM-TESTS.md](UPSTREAM-TESTS.md).
12. The historical Betti routine groups chains by internal degree. For a
   nonhomogeneous differential this misses degree-lowering scalar terms.
   For example, after shifting the monoid relation x²−1, the differential
   contains 2x. George calculates ungraded homology by exact matrix ranks,
   checks that successive augmented differentials compose to zero, and
   saves those results separately in `homology.json`.
13. The header of `MINRESOLUTION` itself warns that it gives incorrect results
   or errors. This is distinct from `MINR`, which is included in the
   historical regression list. Passing that list does not validate every
   experimental routine in the distribution.

The CLISP and PSL historical files are not identical specifications. Known
platform/history differences include signs of linear relations, the printed
MAXDEG comment, inherited elimination-mode settings, and the PB display
change. Exact legacy comparisons use the supplied **2007 CLISP run**, with
older PSL files retained as additional historical evidence.

## ECL portability findings

The 2026-10-01 memory update adds a host-level heap setting and catches
`EXT:STORAGE-EXHAUSTED`, which is a `STORAGE-CONDITION` and therefore does
not inherit from `ERROR`. ECL's heap is configured with `EXT:SET-LIMIT`;
the Emscripten link sets `MAXIMUM_MEMORY` to 4 GiB. The UI offers at most
3.5 GiB for Lisp, leaving 512 MiB for other Wasm allocations. This does not
change Bergman's algebraic routines. Saved basis output survives a handled
heap failure, while the affected worker is released. See the dated memory
evidence in [VALIDATION.md](VALIDATION.md).

The original build cannot simply compile native `.fas` files and put them in
Wasm: those files contain host machine code. George uses ECL portable
bytecode, retaining Bergman's filenames. Its loader reads serialization with
ECL's reader but executes each decoded form using Bergman's package and
readtable. ECL's default bytecode loader uses its serialization context for
both operations, which breaks dynamic `INTERN` and case-sensitive symbols.

Other adapters are explicit and applied only to build copies:

- Standard input must be bound to a stream, not NIL.
- Closed output streams need the CLISP-compatible terminal fallback.
- An extensionless group such as `hseries` must take precedence over its
  single-module `hseries.fas` file.
- Autoload macros return a copy of their expansion, allowing ECL to expand
  the newly loaded definition rather than treating the unchanged form as a
  function call.
- The invalid legacy Maplst call is deferred until execution; ECL's bytecode
  compiler otherwise rejects the entire function before it can be loaded.
- ECL's column query gets a real stream when Bergman passes NIL.
- Timing diagnostics use elapsed time because browser CPU-usage syscalls are
  unavailable. These diagnostics are not compared as algebraic results.

## OCaml implementation

The browser uses `Field.Float` (`bergmanjs.ml`), so its arithmetic is not an
exact oracle for general rational coefficients. The native Anick examples
use `Field.Int`, whose inverse operation only accepts +1 and −1. Comparisons
with those examples use their exact supported coefficients.

`tools/bergman/parser.mly` accepts single-character generators and numeric
coefficients 0 and 1, with negation and integer exponents. Its interface's
maximum degree is read after Buchberger completion and bounds the resolution,
not completion itself. The callback performs the calculation synchronously.
These are important differences from George's worker and its algebraic
degree limit; equally named controls are not interchangeable specifications.

`src/algebra.ml` completes presentations by exploring overlap ambiguities.
Its resolution code assumes a convergent/reduced presentation. It supports
both the augmentation sending generators to 0 and the augmentation sending
them to 1. For the latter, George uses the change of variables x = u + 1,
retains the original basis, and labels resolution generators as shifted.

`src/field.ml` also contains a fractions functor with independent defects:

- Canonicalization derives the denominator from the already-divided
  numerator instead of the original denominator.
- Addition uses denominator c·d instead of b·d.
- Multiplication likewise uses c·d instead of b·d.

For instance, its raw multiplication sends (1/2)(1/3) to 1/3, and its raw
addition sends 1/2+1/3 to 5/3. This module is not the browser's Float path.
Its output must not be treated as a rational-arithmetic reference.

The upstream dune file registers 24 test aliases, spanning categories,
rewriting, automata and other subjects as well as algebra. Running all of
those tests validates that reference checkout; it does **not** mean George
implements those unrelated APIs. The directly relevant examples include
`anick0` (exterior algebra on three generators), `anick1` (chains for aaa),
`anick2` (the cubic x³+y³+z³−xyz), `anick3` (x²−1 with monoid augmentation),
and `mirai` (a nonhomogeneous contraction example). Commented presentations
and the six UI families are inventoried separately in the validation tools.

## Limits of the evidence

Regression equality, independent ideal-membership checks, critical-pair
reductions, known Hilbert dimensions and differential checks provide
complementary evidence. They are not a proof of correctness for every
presentation, coefficient field, order or experimental Bergman procedure.
A bounded basis is labelled partial.
Original Bergman supports longer names: `bnminout.sl` describes names such
as `x1`, `y1`, `D1` and `D2`, and chains internally use monomial indices.
Its default `PRINTCHAIN` in `chrecord.sl` joins printed vertices without an
edge separator. George's former character-string reconstruction imposed a
single-letter restriction; that was our limitation. The explicit
`GEORGEWRITERESOLUTION` command in `ports/common/george-overlay.sl` now walks
the original chain and tensor objects using their access macros. It exports
ordered generator indices and exact numerator/denominator strings in
`resolution.jsonl`, without changing `ANICKDISPLAY` or legacy outputs.
`web/src/resolution-data.js` validates this structure and retains whole tokens
for homology, the independent differential checker and the browser display.
All counts and timings
belong in `docs/development/VALIDATION.md`, with the exact build hashes recorded there.
