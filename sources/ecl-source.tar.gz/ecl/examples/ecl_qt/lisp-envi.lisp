(princ "Lisp Environment Booted.")


