/* -*- Mode: C; c-basic-offset: 2; indent-tabs-mode: nil -*- */
/* vim: set filetype=c tabstop=2 shiftwidth=2 expandtab: */

/*
 * apply.c - interface to C call mechanism
 *
 * Copyright (c) 1993 Giuseppe Attardi
 * Copyright (c) 2001 Juan Jose Garcia Ripoll
 *
 * See file 'LICENSE' for the copyright details.
 *
 */

#include <ecl/ecl.h>
#include <ecl/ecl-inl.h>
#include <ecl/internal.h>
#include <ecl/external.h>
#include <ecl/nucleus.h>

cl_objectfn
ecl_function_dispatch(cl_env_ptr env, cl_object x)
{
  cl_object fun = x;
  if (ecl_unlikely(fun == ECL_NIL))
    FEundefined_function(x);
  switch (ecl_t_of(fun)) {
  case t_cfunfixed:
    env->function = fun;
    return fun->cfunfixed.entry;
  case t_cfun:
    env->function = fun;
    return fun->cfun.entry;
  case t_cclosure:
    env->function = fun;
    return fun->cclosure.entry;
  case t_instance:
    env->function = fun;
    return fun->instance.entry;
  case t_symbol:
    fun = ECL_SYM_FUN(fun);
    env->function = fun;
    return fun->cfun.entry;
  case t_bytecodes:
    env->function = fun;
    return fun->bytecodes.entry;
  case t_bclosure:
    env->function = fun;
    return fun->bclosure.entry;
  default:
    FEinvalid_function(x);
  }
  _ecl_unexpected_return();
}

/* Calling conventions:
 * Compiled C code calls lisp function supplying #args, and args.
 *
 * Linking function performs check_args, gets jmp_buf with _setjmp, then
 *
 * if cfun then stores C code address into function link location and transfers
 * to jmp_buf at cf_self

 * if cclosure then replaces #args with cc_env and calls cc_self otherwise, it
 * emulates funcall.
 */

cl_object
ecl_apply_from_stack_frame(cl_object frame, cl_object x)
{
  cl_object *sp = ECL_STACK_FRAME_PTR(frame);
  cl_index narg = frame->frame.size;
  cl_object fun = x;
  cl_object ret;
  frame->frame.env->stack_frame = frame;
 AGAIN:
  frame->frame.env->function = fun;
  if (ecl_unlikely(fun == ECL_NIL))
    FEundefined_function(x);
  switch (ecl_t_of(fun)) {
  case t_cfunfixed:
    if (ecl_unlikely(narg != (cl_index)fun->cfun.narg))
      FEwrong_num_arguments(fun);
    ret = APPLY_fixed(narg, fun->cfunfixed.entry_fixed, sp);
    break;
  case t_cfun:
    ret = APPLY(narg, fun->cfun.entry, sp);
    break;
  case t_cclosure:
    ret = APPLY(narg, fun->cclosure.entry, sp);
    break;
  case t_instance:
    switch (fun->instance.isgf) {
    case ECL_STANDARD_DISPATCH:
    case ECL_RESTRICTED_DISPATCH:
      ret = _ecl_standard_dispatch(frame, fun);
      break;
    case ECL_USER_DISPATCH:
      fun = fun->instance.gfdef;
      goto AGAIN;
    case ECL_READER_DISPATCH:
    case ECL_WRITER_DISPATCH:
      ret = APPLY(narg, fun->instance.entry, sp);
      break;
    default:
      FEinvalid_function(fun);
    }
    break;
  case t_symbol:
    if (ecl_unlikely(!ECL_FBOUNDP(fun)))
      FEundefined_function(fun);
    fun = ECL_SYM_FUN(fun);
    goto AGAIN;
  case t_bytecodes:
    ret = ecl_interpret(frame, ECL_NIL, fun);
    break;
  case t_bclosure:
    ret = ecl_interpret(frame, fun->bclosure.lex, fun->bclosure.code);
    break;
  default:
    FEinvalid_function(x);
  }
  frame->frame.env->stack_frame = NULL; /* for gc's sake */
  return ret;
}

cl_object
cl_funcall(cl_narg narg, cl_object function, ...)
{
  cl_object output;
  --narg;
  {
    ECL_STACK_FRAME_VARARGS_BEGIN(narg, function, frame);
    output = ecl_apply_from_stack_frame(frame, function);
    ECL_STACK_FRAME_VARARGS_END(frame);
  }
  return output;
}

cl_object *
_ecl_va_sp(cl_narg narg)
{
  return ECL_STACK_FRAME_PTR(ecl_process_env()->stack_frame) + narg;
}

#if !(ECL_C_ARGUMENTS_LIMIT == 63)
#error "Please adjust code to the constant!"
#endif

cl_object
APPLY(cl_narg n, cl_objectfn fn, cl_object *x)
{
  switch (n) {
  case 0:  return (*fn)(n);
  case 1:  return (*fn)(n, x[0]);
  case 2:  return (*fn)(n, x[0],x[1]);
  case 3:  return (*fn)(n, x[0],x[1],x[2]);
  case 4:  return (*fn)(n, x[0],x[1],x[2],x[3]);
  case 5:  return (*fn)(n, x[0],x[1],x[2],x[3],x[4]);
  case 6:  return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5]);
  case 7:  return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6]);
  case 8:  return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7]);
  case 9:  return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8]);
  case 10: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9]);
  case 11: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10]);
  case 12: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11]);
  case 13: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12]);
  case 14: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13]);
  case 15: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14]);
  case 16: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15]);
  case 17: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16]);
  case 18: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17]);
  case 19: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18]);
  case 20: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19]);
  case 21: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20]);
  case 22: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21]);
  case 23: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                        x[22]);
  case 24: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                        x[22],x[23]);
  case 25: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                        x[22],x[23],x[24]);
  case 26: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                        x[22],x[23],x[24],x[25]);
  case 27: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                        x[22],x[23],x[24],x[25],x[26]);
  case 28: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                        x[22],x[23],x[24],x[25],x[26],x[27]);
  case 29: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                        x[22],x[23],x[24],x[25],x[26],x[27],x[28]);
  case 30: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                        x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                        x[29]);
  case 31: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                        x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                        x[29],x[30]);
  case 32: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                        x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                        x[29],x[30],x[31]);
  case 33: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                        x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                        x[29],x[30],x[31],x[32]);
  case 34: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                        x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                        x[29],x[30],x[31],x[32],x[33]);
  case 35: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                        x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                        x[29],x[30],x[31],x[32],x[33],x[34]);
  case 36: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                        x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                        x[29],x[30],x[31],x[32],x[33],x[34],x[35]);
  case 37: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                        x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                        x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                        x[36]);
  case 38: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                        x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                        x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                        x[36],x[37]);
  case 39: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                        x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                        x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                        x[36],x[37],x[38]);
  case 40: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                        x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                        x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                        x[36],x[37],x[38],x[39]);
  case 41: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                        x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                        x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                        x[36],x[37],x[38],x[39],x[40]);
  case 42: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                        x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                        x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                        x[36],x[37],x[38],x[39],x[40],x[41]);
  case 43: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                        x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                        x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                        x[36],x[37],x[38],x[39],x[40],x[41],x[42]);
  case 44: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                        x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                        x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                        x[36],x[37],x[38],x[39],x[40],x[41],x[42],
                        x[43]);
  case 45: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                        x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                        x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                        x[36],x[37],x[38],x[39],x[40],x[41],x[42],
                        x[43],x[44]);
  case 46: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                        x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                        x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                        x[36],x[37],x[38],x[39],x[40],x[41],x[42],
                        x[43],x[44],x[45]);
  case 47: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                        x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                        x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                        x[36],x[37],x[38],x[39],x[40],x[41],x[42],
                        x[43],x[44],x[45],x[46]);
  case 48: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                        x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                        x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                        x[36],x[37],x[38],x[39],x[40],x[41],x[42],
                        x[43],x[44],x[45],x[46],x[47]);
  case 49: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                        x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                        x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                        x[36],x[37],x[38],x[39],x[40],x[41],x[42],
                        x[43],x[44],x[45],x[46],x[47],x[48]);
  case 50: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                        x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                        x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                        x[36],x[37],x[38],x[39],x[40],x[41],x[42],
                        x[43],x[44],x[45],x[46],x[47],x[48],x[49]);
  case 51: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                        x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                        x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                        x[36],x[37],x[38],x[39],x[40],x[41],x[42],
                        x[43],x[44],x[45],x[46],x[47],x[48],x[49],
                        x[50]);
  case 52: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                        x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                        x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                        x[36],x[37],x[38],x[39],x[40],x[41],x[42],
                        x[43],x[44],x[45],x[46],x[47],x[48],x[49],
                        x[50],x[51]);
  case 53: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                        x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                        x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                        x[36],x[37],x[38],x[39],x[40],x[41],x[42],
                        x[43],x[44],x[45],x[46],x[47],x[48],x[49],
                        x[50],x[51],x[52]);
  case 54: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                        x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                        x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                        x[36],x[37],x[38],x[39],x[40],x[41],x[42],
                        x[43],x[44],x[45],x[46],x[47],x[48],x[49],
                        x[50],x[51],x[52],x[53]);
  case 55: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                        x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                        x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                        x[36],x[37],x[38],x[39],x[40],x[41],x[42],
                        x[43],x[44],x[45],x[46],x[47],x[48],x[49],
                        x[50],x[51],x[52],x[53],x[54]);
  case 56: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                        x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                        x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                        x[36],x[37],x[38],x[39],x[40],x[41],x[42],
                        x[43],x[44],x[45],x[46],x[47],x[48],x[49],
                        x[50],x[51],x[52],x[53],x[54],x[55]);
  case 57: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                        x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                        x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                        x[36],x[37],x[38],x[39],x[40],x[41],x[42],
                        x[43],x[44],x[45],x[46],x[47],x[48],x[49],
                        x[50],x[51],x[52],x[53],x[54],x[55],x[56]);
  case 58: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                        x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                        x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                        x[36],x[37],x[38],x[39],x[40],x[41],x[42],
                        x[43],x[44],x[45],x[46],x[47],x[48],x[49],
                        x[50],x[51],x[52],x[53],x[54],x[55],x[56],
                        x[57]);
  case 59: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                        x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                        x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                        x[36],x[37],x[38],x[39],x[40],x[41],x[42],
                        x[43],x[44],x[45],x[46],x[47],x[48],x[49],
                        x[50],x[51],x[52],x[53],x[54],x[55],x[56],
                        x[57],x[58]);
  case 60: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                        x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                        x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                        x[36],x[37],x[38],x[39],x[40],x[41],x[42],
                        x[43],x[44],x[45],x[46],x[47],x[48],x[49],
                        x[50],x[51],x[52],x[53],x[54],x[55],x[56],
                        x[57],x[58],x[59]);
  case 61: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                        x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                        x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                        x[36],x[37],x[38],x[39],x[40],x[41],x[42],
                        x[43],x[44],x[45],x[46],x[47],x[48],x[49],
                        x[50],x[51],x[52],x[53],x[54],x[55],x[56],
                        x[57],x[58],x[59],x[60]);
  case 62: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                        x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                        x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                        x[36],x[37],x[38],x[39],x[40],x[41],x[42],
                        x[43],x[44],x[45],x[46],x[47],x[48],x[49],
                        x[50],x[51],x[52],x[53],x[54],x[55],x[56],
                        x[57],x[58],x[59],x[60],x[61]);
  case 63: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                        x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                        x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                        x[36],x[37],x[38],x[39],x[40],x[41],x[42],
                        x[43],x[44],x[45],x[46],x[47],x[48],x[49],
                        x[50],x[51],x[52],x[53],x[54],x[55],x[56],
                        x[57],x[58],x[59],x[60],x[61],x[62]);
  default: return (*fn)(n, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                        x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                        x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                        x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                        x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                        x[36],x[37],x[38],x[39],x[40],x[41],x[42],
                        x[43],x[44],x[45],x[46],x[47],x[48],x[49],
                        x[50],x[51],x[52],x[53],x[54],x[55],x[56],
                        x[57],x[58],x[59],x[60],x[61],x[62],x[63]);
    /* Arguments above 64 have been pushed on the stack */
  } 
}

cl_object
APPLY_fixed(cl_narg n, cl_object (*fn)(), cl_object *x)
{
  switch (n) {
  case 0:  return (*((cl_objectfn_fixed0)fn))();
  case 1:  return (*((cl_objectfn_fixed1)fn))(x[0]);
  case 2:  return (*((cl_objectfn_fixed2)fn))(x[0],x[1]);
  case 3:  return (*((cl_objectfn_fixed3)fn))(x[0],x[1],x[2]);
  case 4:  return (*((cl_objectfn_fixed4)fn))(x[0],x[1],x[2],x[3]);
  case 5:  return (*((cl_objectfn_fixed5)fn))(x[0],x[1],x[2],x[3],x[4]);
  case 6:  return (*((cl_objectfn_fixed6)fn))(x[0],x[1],x[2],x[3],x[4],x[5]);
  case 7:  return (*((cl_objectfn_fixed7)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6]);
  case 8:  return (*((cl_objectfn_fixed8)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7]);
  case 9:  return (*((cl_objectfn_fixed9)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                              x[8]);
  case 10: return (*((cl_objectfn_fixed10)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9]);
  case 11: return (*((cl_objectfn_fixed11)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10]);
  case 12: return (*((cl_objectfn_fixed12)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11]);
  case 13: return (*((cl_objectfn_fixed13)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12]);
  case 14: return (*((cl_objectfn_fixed14)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13]);
  case 15: return (*((cl_objectfn_fixed15)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14]);
  case 16: return (*((cl_objectfn_fixed16)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15]);
  case 17: return (*((cl_objectfn_fixed17)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16]);
  case 18: return (*((cl_objectfn_fixed18)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17]);
  case 19: return (*((cl_objectfn_fixed19)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18]);
  case 20: return (*((cl_objectfn_fixed20)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19]);
  case 21: return (*((cl_objectfn_fixed21)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20]);
  case 22: return (*((cl_objectfn_fixed22)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20],x[21]);
  case 23: return (*((cl_objectfn_fixed23)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                                               x[22]);
  case 24: return (*((cl_objectfn_fixed24)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                                               x[22],x[23]);
  case 25: return (*((cl_objectfn_fixed25)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                                               x[22],x[23],x[24]);
  case 26: return (*((cl_objectfn_fixed26)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                                               x[22],x[23],x[24],x[25]);
  case 27: return (*((cl_objectfn_fixed27)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                                               x[22],x[23],x[24],x[25],x[26]);
  case 28: return (*((cl_objectfn_fixed28)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                                               x[22],x[23],x[24],x[25],x[26],x[27]);
  case 29: return (*((cl_objectfn_fixed29)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                                               x[22],x[23],x[24],x[25],x[26],x[27],x[28]);
  case 30: return (*((cl_objectfn_fixed30)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                                               x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                                               x[29]);
  case 31: return (*((cl_objectfn_fixed31)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                                               x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                                               x[29],x[30]);
  case 32: return (*((cl_objectfn_fixed32)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                                               x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                                               x[29],x[30],x[31]);
  case 33: return (*((cl_objectfn_fixed33)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                                               x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                                               x[29],x[30],x[31],x[32]);
  case 34: return (*((cl_objectfn_fixed34)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                                               x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                                               x[29],x[30],x[31],x[32],x[33]);
  case 35: return (*((cl_objectfn_fixed35)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                                               x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                                               x[29],x[30],x[31],x[32],x[33],x[34]);
  case 36: return (*((cl_objectfn_fixed36)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                                               x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                                               x[29],x[30],x[31],x[32],x[33],x[34],x[35]);
  case 37: return (*((cl_objectfn_fixed37)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                                               x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                                               x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                                               x[36]);
  case 38: return (*((cl_objectfn_fixed38)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                                               x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                                               x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                                               x[36],x[37]);
  case 39: return (*((cl_objectfn_fixed39)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                                               x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                                               x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                                               x[36],x[37],x[38]);
  case 40: return (*((cl_objectfn_fixed40)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                                               x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                                               x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                                               x[36],x[37],x[38],x[39]);
  case 41: return (*((cl_objectfn_fixed41)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                                               x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                                               x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                                               x[36],x[37],x[38],x[39],x[40]);
  case 42: return (*((cl_objectfn_fixed42)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                                               x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                                               x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                                               x[36],x[37],x[38],x[39],x[40],x[41]);
  case 43: return (*((cl_objectfn_fixed43)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                                               x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                                               x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                                               x[36],x[37],x[38],x[39],x[40],x[41],x[42]);
  case 44: return (*((cl_objectfn_fixed44)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                                               x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                                               x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                                               x[36],x[37],x[38],x[39],x[40],x[41],x[42],
                                               x[43]);
  case 45: return (*((cl_objectfn_fixed45)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                                               x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                                               x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                                               x[36],x[37],x[38],x[39],x[40],x[41],x[42],
                                               x[43],x[44]);
  case 46: return (*((cl_objectfn_fixed46)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                                               x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                                               x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                                               x[36],x[37],x[38],x[39],x[40],x[41],x[42],
                                               x[43],x[44],x[45]);
  case 47: return (*((cl_objectfn_fixed47)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                                               x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                                               x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                                               x[36],x[37],x[38],x[39],x[40],x[41],x[42],
                                               x[43],x[44],x[45],x[46]);
  case 48: return (*((cl_objectfn_fixed48)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                                               x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                                               x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                                               x[36],x[37],x[38],x[39],x[40],x[41],x[42],
                                               x[43],x[44],x[45],x[46],x[47]);
  case 49: return (*((cl_objectfn_fixed49)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                                               x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                                               x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                                               x[36],x[37],x[38],x[39],x[40],x[41],x[42],
                                               x[43],x[44],x[45],x[46],x[47],x[48]);
  case 50: return (*((cl_objectfn_fixed50)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                                               x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                                               x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                                               x[36],x[37],x[38],x[39],x[40],x[41],x[42],
                                               x[43],x[44],x[45],x[46],x[47],x[48],x[49]);
  case 51: return (*((cl_objectfn_fixed51)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                                               x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                                               x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                                               x[36],x[37],x[38],x[39],x[40],x[41],x[42],
                                               x[43],x[44],x[45],x[46],x[47],x[48],x[49],
                                               x[50]);
  case 52: return (*((cl_objectfn_fixed52)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                                               x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                                               x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                                               x[36],x[37],x[38],x[39],x[40],x[41],x[42],
                                               x[43],x[44],x[45],x[46],x[47],x[48],x[49],
                                               x[50],x[51]);
  case 53: return (*((cl_objectfn_fixed53)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                                               x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                                               x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                                               x[36],x[37],x[38],x[39],x[40],x[41],x[42],
                                               x[43],x[44],x[45],x[46],x[47],x[48],x[49],
                                               x[50],x[51],x[52]);
  case 54: return (*((cl_objectfn_fixed54)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                                               x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                                               x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                                               x[36],x[37],x[38],x[39],x[40],x[41],x[42],
                                               x[43],x[44],x[45],x[46],x[47],x[48],x[49],
                                               x[50],x[51],x[52],x[53]);
  case 55: return (*((cl_objectfn_fixed55)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                                               x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                                               x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                                               x[36],x[37],x[38],x[39],x[40],x[41],x[42],
                                               x[43],x[44],x[45],x[46],x[47],x[48],x[49],
                                               x[50],x[51],x[52],x[53],x[54]);
  case 56: return (*((cl_objectfn_fixed56)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                                               x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                                               x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                                               x[36],x[37],x[38],x[39],x[40],x[41],x[42],
                                               x[43],x[44],x[45],x[46],x[47],x[48],x[49],
                                               x[50],x[51],x[52],x[53],x[54],x[55]);
  case 57: return (*((cl_objectfn_fixed57)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                                               x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                                               x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                                               x[36],x[37],x[38],x[39],x[40],x[41],x[42],
                                               x[43],x[44],x[45],x[46],x[47],x[48],x[49],
                                               x[50],x[51],x[52],x[53],x[54],x[55],x[56]);
  case 58: return (*((cl_objectfn_fixed58)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                                               x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                                               x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                                               x[36],x[37],x[38],x[39],x[40],x[41],x[42],
                                               x[43],x[44],x[45],x[46],x[47],x[48],x[49],
                                               x[50],x[51],x[52],x[53],x[54],x[55],x[56],
                                               x[57]);
  case 59: return (*((cl_objectfn_fixed59)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                                               x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                                               x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                                               x[36],x[37],x[38],x[39],x[40],x[41],x[42],
                                               x[43],x[44],x[45],x[46],x[47],x[48],x[49],
                                               x[50],x[51],x[52],x[53],x[54],x[55],x[56],
                                               x[57],x[58]);
  case 60: return (*((cl_objectfn_fixed60)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                                               x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                                               x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                                               x[36],x[37],x[38],x[39],x[40],x[41],x[42],
                                               x[43],x[44],x[45],x[46],x[47],x[48],x[49],
                                               x[50],x[51],x[52],x[53],x[54],x[55],x[56],
                                               x[57],x[58],x[59]);
  case 61: return (*((cl_objectfn_fixed61)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                                               x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                                               x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                                               x[36],x[37],x[38],x[39],x[40],x[41],x[42],
                                               x[43],x[44],x[45],x[46],x[47],x[48],x[49],
                                               x[50],x[51],x[52],x[53],x[54],x[55],x[56],
                                               x[57],x[58],x[59],x[60]);
  case 62: return (*((cl_objectfn_fixed62)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                                               x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                                               x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                                               x[36],x[37],x[38],x[39],x[40],x[41],x[42],
                                               x[43],x[44],x[45],x[46],x[47],x[48],x[49],
                                               x[50],x[51],x[52],x[53],x[54],x[55],x[56],
                                               x[57],x[58],x[59],x[60],x[61]);
  case 63: return (*((cl_objectfn_fixed63)fn))(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],
                                               x[8],x[9],x[10],x[11],x[12],x[13],x[14],
                                               x[15],x[16],x[17],x[18],x[19],x[20],x[21],
                                               x[22],x[23],x[24],x[25],x[26],x[27],x[28],
                                               x[29],x[30],x[31],x[32],x[33],x[34],x[35],
                                               x[36],x[37],x[38],x[39],x[40],x[41],x[42],
                                               x[43],x[44],x[45],x[46],x[47],x[48],x[49],
                                               x[50],x[51],x[52],x[53],x[54],x[55],x[56],
                                               x[57],x[58],x[59],x[60],x[61],x[62]);
  default:
    FEprogram_error("Too many arguments", 0);
  }
  _ecl_unexpected_return();
}
